using System;
using BLPPCounter.CalculatorStuffs;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Enums;
using Zenject;

namespace BLPPCounter.Utils.Misc_Classes
{
    internal class LeaderboardSelector
    {
        [Inject]
        private readonly BLAPI blAPI = null!;

        [Inject]
        private readonly SSAPI ssAPI = null!;

        [Inject]
        private readonly APAPI apAPI = null!;

        [Inject]
        private readonly BLCalc blCalc = null!;

        [Inject]
        private readonly SSCalc ssCalc = null!;

        [Inject]
        private readonly APCalc apCalc = null!;

        public APIHandler GetAPI(Leaderboards type) =>
            type switch
            {
                Leaderboards.Beatleader => blAPI,
                Leaderboards.Scoresaber => ssAPI,
                Leaderboards.Accsaber => apAPI,
                _ => throw new ArgumentOutOfRangeException(nameof(type), type, null),
            };

        public Calculator GetCalc(Leaderboards type) =>
            type switch
            {
                Leaderboards.Beatleader => blCalc,
                Leaderboards.Scoresaber => ssCalc,
                Leaderboards.Accsaber => apCalc,
                _ => throw new ArgumentOutOfRangeException(nameof(type), type, null),
            };
    }
}
