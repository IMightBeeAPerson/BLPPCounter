using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using BLPPCounter.Helpfuls;
using BLPPCounter.Settings.Configs;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Enums;
using BLPPCounter.Utils.Safety;
using BLPPCounter.Utils.Serializable_Classes;
using IPA.Utilities.Async;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Zenject;

namespace BLPPCounter.Utils.Misc_Classes
{
    internal sealed class Targeter : IInitializable
    {
        [Inject]
        private readonly PluginConfig _config = null!;

        [Inject]
        private readonly MainThreadDispatcher _mainThreadDispatcher = null!;

        public const string NO_TARGET = "None";
        public const int MAX_LIST_LENGTH = 100;

        public event Action? InitTaskCompleted;
        public event Action? TargetListReloaded;

        /*
         * These are source lists. They contain the actual target data, including
         * names and ranks. The display lists below are rebuilt from these.
         */
        private readonly List<CustomTarget> _clanSource = [];
        private readonly List<CustomTarget> _followerSource = [];

        /*
         * These lists are never replaced. TargeterInfo holds references to them,
         * so mutating them in place keeps its read-only views current.
         */
        private readonly List<TargetPair> _clanTargets = [];
        private readonly List<TargetPair> _followerTargets = [];
        private readonly List<TargetPair> _customTargets = [];

        private readonly HashSet<long> _usedIds = [];
        private readonly Dictionary<string, string> _idToNames = [];

        private Task _initializationTask = Task.CompletedTask;
        private bool _initializationStarted;

        private TargeterInfo? _target;

        public TargeterInfo Target =>
            _target ?? throw new InvalidOperationException("Targeter has not completed initialization.");

        public Task InitializationTask =>
            _initializationStarted
                ? _initializationTask
                : throw new InvalidOperationException("Targeter.Initialize has not been called yet.");

        public void Initialize()
        {
            if (_initializationStarted)
                return;

            _initializationStarted = true;
            _initializationTask = InitializeAsync();
        }

        public Task WaitUntilInitializedAsync() => InitializationTask;

        private async Task InitializeAsync()
        {
            try
            {
                string playerId = await GetCurrentPlayerIdAsync();

                (string clanJson, string playerName) = await RequestClan(playerId);

                List<CustomTarget> clanTargets = ParseClanTargets(clanJson);

                List<CustomTarget>? cachedFollowers = TryLoadCachedFollowers();

                List<CustomTarget> followers;

                if (cachedFollowers is not null)
                {
                    followers = cachedFollowers;
                }
                else
                {
                    followers = await FetchFollowersAsync(playerId) ?? [];
                }

                List<CustomTarget> customTargets = await ResolveCustomTargetRanksAsync(_config.CustomTargets);

                await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
                {
                    _clanSource.Clear();
                    _clanSource.AddRange(clanTargets);

                    _followerSource.Clear();
                    _followerSource.AddRange(followers);

                    _config.CustomTargets = customTargets;

                    RebuildTargetData(removeDuplicateCustomTargets: true);

                    _target = new TargeterInfo(
                        _config,
                        _clanTargets,
                        _followerTargets,
                        _customTargets,
                        _usedIds,
                        _idToNames
                    )
                    {
                        PlayerID = playerId,
                        PlayerName = playerName,
                    };

                    InitTaskCompleted?.Invoke();
                });

                await EnsureConfiguredTargetExistsAsync();
            }
            catch (Exception ex)
            {
                Plugin.Log.Error($"Failed to initialize Targeter:\n{ex}");
                throw;
            }
        }

        /// <summary>
        /// Refreshes rank/name data for every custom target in the configuration. Failed individual requests retain
        /// their existing target data instead of silently removing the target.
        /// </summary>
        internal async Task ReloadCustomPlayersAsync()
        {
            await WaitUntilInitializedAsync();

            List<CustomTarget> refreshed = await RefreshTargetRanksAsync(_config.CustomTargets);

            await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
            {
                _config.CustomTargets = refreshed;
                RebuildTargetData(removeDuplicateCustomTargets: false);

                TargetListReloaded?.Invoke();
            });
        }

        /// <summary>
        /// Refreshes BeatLeader-followed players and optional Steam friends. If the request fails, the current follower
        /// list remains intact.
        /// </summary>
        internal async Task ReloadFollowersAsync()
        {
            await WaitUntilInitializedAsync();

            List<CustomTarget>? followers = await FetchFollowersAsync(Target.PlayerID);

            if (followers is null)
            {
                Plugin.Log.Warn("Follower refresh failed; retaining the existing follower list.");
                return;
            }

            await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
            {
                _followerSource.Clear();
                _followerSource.AddRange(followers);

                RebuildTargetData(removeDuplicateCustomTargets: false);

                TargetListReloaded?.Invoke();
            });
        }

        internal async Task SaveAllAsync()
        {
            await WaitUntilInitializedAsync();

            List<CustomTarget> followers = await UnityMainThreadTaskScheduler.Factory.StartNew(() => _followerTargets
                    .Where(target => target.Rank >= 0)
                    .Where(target => _idToNames.ContainsKey(target.Id))
                    .Select(target => new CustomTarget(_idToNames[target.Id], long.Parse(target.Id), target.Rank))
                    .ToList());

            try
            {
                string? directory = Path.GetDirectoryName(HelpfulPaths.TARGET_DATA);

                if (!string.IsNullOrEmpty(directory))
                    Directory.CreateDirectory(directory);

                using StreamWriter writer = new(HelpfulPaths.TARGET_DATA);

                JsonSerializer serializer = new();
                serializer.Serialize(writer, followers);
            }
            catch (Exception ex)
            {
                Plugin.Log.Error($"Failed to save follower targets:\n{ex}");
            }
        }

        /// <summary>
        /// Adds a target to the runtime display/index data. The current UI already adds the target to
        /// PluginConfig.CustomTargets before calling the old AddTarget method, so this intentionally does not add
        /// another copy to configuration.
        /// </summary>
        internal async Task AddTargetAsync(CustomTarget target)
        {
            await WaitUntilInitializedAsync();

            await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
            {
                if (_config.CustomTargets.All(existing => existing.ID != target.ID))
                {
                    _config.CustomTargets.Add(target);
                }

                RebuildTargetData(removeDuplicateCustomTargets: false);

                TargetListReloaded?.Invoke();
            });
        }

        internal Task AddTargetAsync(string name, string id, int rank)
        {
            if (!long.TryParse(id, out long parsedId))
            {
                throw new ArgumentException($"\"{id}\" is not a valid player ID.", nameof(id));
            }

            return AddTargetAsync(new CustomTarget(name, parsedId, rank));
        }

        internal void SetTarget(string name, long id)
        {
            _config.Target = name;
            _config.TargetID = id;
        }

        internal void SetTarget(CustomTarget target) => SetTarget(target.Name, target.ID);

        /// <summary>
        /// Deletes a custom target. Its ID becomes reusable immediately, except when that player still exists in the
        /// clan or follower target sources.
        /// </summary>
        internal async Task<bool> DeleteTargetAsync(string id)
        {
            await WaitUntilInitializedAsync();

            if (!long.TryParse(id, out long parsedId))
                return false;

            return await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
            {
                int index = _config.CustomTargets.FindIndex(target => target.ID == parsedId);

                if (index < 0)
                    return false;

                _config.CustomTargets.RemoveAt(index);

                if (_config.TargetID == parsedId)
                {
                    _config.TargetID = -1;
                    _config.Target = NO_TARGET;
                }

                /*
                 * RebuildTargetData reconstructs UsedIDs and IDtoNames from
                 * clan/follower/custom sources. Therefore the deleted ID is
                 * removed if it is no longer represented by any source.
                 */
                RebuildTargetData(removeDuplicateCustomTargets: false);

                TargetListReloaded?.Invoke();
                return true;
            });
        }

        private async Task EnsureConfiguredTargetExistsAsync()
        {
            bool targetExists = await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
            {
                if (_config.TargetID < 0)
                    return true;

                string id = _config.TargetID.ToString();

                return _idToNames.TryGetValue(id, out string? name)
                    && string.Equals(name, _config.Target, StringComparison.Ordinal);
            });

            if (targetExists)
                return;

            if (_config.TargetID < 0)
            {
                await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
                {
                    _config.Target = NO_TARGET;
                });

                return;
            }

            try
            {
                CustomTarget target = await CustomTarget.ConvertToId(_config.TargetID);

                await AddTargetAsync(target);
            }
            catch (Exception ex)
            {
                Plugin.Log.Warn($"Could not resolve saved target ID " + $"\"{_config.TargetID}\": {ex.Message}");

                await UnityMainThreadTaskScheduler.Factory.StartNew(() =>
                {
                    _config.TargetID = -1;
                    _config.Target = NO_TARGET;
                });
            }
        }

        /// <summary>
        /// Recreates all derived data from the three source collections. Precedence intentionally matches the previous
        /// behavior: clan, then followers, then custom targets.
        /// </summary>
        private void RebuildTargetData(bool removeDuplicateCustomTargets)
        {
            _clanTargets.Clear();
            _followerTargets.Clear();
            _customTargets.Clear();
            _usedIds.Clear();
            _idToNames.Clear();

            AddSourceTargets(_clanSource, _clanTargets, "home clan");

            AddSourceTargets(_followerSource, _followerTargets, "follower list");

            List<CustomTarget>? validCustomTargets = removeDuplicateCustomTargets ? [] : null;

            foreach (CustomTarget target in _config.CustomTargets)
            {
                if (target.ID <= 0)
                    continue;

                if (!_usedIds.Add(target.ID))
                {
                    LogDuplicate(target.ID, "custom targets list");
                    continue;
                }

                _idToNames[target.ID.ToString()] = target.Name;
                _customTargets.Add(new TargetPair(target.ID.ToString(), target.Rank));

                validCustomTargets?.Add(target);
            }

            if (validCustomTargets is not null)
                _config.CustomTargets = validCustomTargets;

            _clanTargets.Sort(CompareTargetPairs);
            _followerTargets.Sort(CompareTargetPairs);
            _customTargets.Sort(CompareTargetPairs);

            _config.CustomTargets.Sort(CompareCustomTargets);
        }

        private void AddSourceTargets(IEnumerable<CustomTarget> source, List<TargetPair> display, string sourceName)
        {
            foreach (CustomTarget target in source)
            {
                if (target.ID <= 0)
                    continue;

                if (!_usedIds.Add(target.ID))
                {
                    LogDuplicate(target.ID, sourceName);
                    continue;
                }

                _idToNames[target.ID.ToString()] = target.Name;
                display.Add(new TargetPair(target.ID.ToString(), target.Rank));
            }
        }

        private void LogDuplicate(long id, string sourceName)
        {
            if (_config.TargeterStartupWarnings)
            {
                Plugin.Log.Warn($"There is a duplicate ID \"{id}\" " + $"inside the {sourceName}.");
            }
        }

        private async Task<List<CustomTarget>> ResolveCustomTargetRanksAsync(IEnumerable<CustomTarget> targets)
        {
            List<CustomTarget> resolved = [];

            foreach (CustomTarget target in targets)
            {
                /*
                 * Positive ranks and -2 are already considered known.
                 * Other ranks are refreshed during startup, as in the old code.
                 */
                if (target.Rank is > 0 or -2)
                {
                    resolved.Add(target);
                    continue;
                }

                try
                {
                    (bool success, HttpContent content) = await APIHandler.CallAPI_Static(
                        string.Format(HelpfulPaths.BLAPI_USERID, target.ID),
                        BLAPI.Throttle
                    );

                    if (!success)
                    {
                        resolved.Add(new CustomTarget(target.Name, target.ID, -2));

                        continue;
                    }

                    JToken player = JToken.Parse(await content.ReadAsStringAsync());

                    string name = player.Value<string>("name") ?? target.Name;

                    int rank = player.Value<int?>("rank") ?? -1;

                    resolved.Add(new CustomTarget(name, target.ID, rank));
                }
                catch (Exception ex)
                {
                    Plugin.Log.Warn($"Could not refresh custom target " + $"\"{target.ID}\": {ex.Message}");

                    resolved.Add(new CustomTarget(target.Name, target.ID, -2));
                }
            }

            resolved.Sort(CompareCustomTargets);
            return resolved;
        }

        private static async Task<List<CustomTarget>> RefreshTargetRanksAsync(IEnumerable<CustomTarget> targets)
        {
            List<CustomTarget> refreshed = [];

            foreach (CustomTarget target in targets)
            {
                try
                {
                    (bool success, HttpContent content) = await APIHandler.CallAPI_Static(
                        string.Format(HelpfulPaths.BLAPI_USERID, target.ID),
                        BLAPI.Throttle
                    );

                    /*
                     * Keep the existing entry if an individual request fails.
                     * A refresh failure should not make a saved target vanish.
                     */
                    if (!success)
                    {
                        refreshed.Add(target);
                        continue;
                    }

                    JToken player = JToken.Parse(await content.ReadAsStringAsync());

                    refreshed.Add(
                        new CustomTarget(
                            player.Value<string>("name") ?? target.Name,
                            target.ID,
                            player.Value<int?>("rank") ?? target.Rank
                        )
                    );
                }
                catch (Exception ex)
                {
                    Plugin.Log.Warn($"Could not refresh custom target " + $"\"{target.ID}\": {ex.Message}");

                    refreshed.Add(target);
                }
            }

            refreshed.Sort(CompareCustomTargets);
            return refreshed;
        }

        private async Task<List<CustomTarget>?> FetchFollowersAsync(string playerId)
        {
            try
            {
                List<CustomTarget> followers =
                [
                    .. await RequestFollowers(playerId, _config.UseSteamFriends, GetSteamFriendIdsAsync),
                ];

                followers.Sort(CompareCustomTargets);
                return followers;
            }
            catch (Exception ex)
            {
                Plugin.Log.Error($"Failed to retrieve follower information:\n{ex}");

                return null;
            }
        }

        private List<CustomTarget>? TryLoadCachedFollowers()
        {
            if (!File.Exists(HelpfulPaths.TARGET_DATA))
                return null;

            try
            {
                using StreamReader reader = File.OpenText(HelpfulPaths.TARGET_DATA);

                JsonSerializer serializer = new();

                return serializer.Deserialize(reader, typeof(List<CustomTarget>)) as List<CustomTarget>
                    ?? throw new JsonSerializationException("Follower cache deserialized as null.");
            }
            catch (Exception ex)
            {
                Plugin.Log.Error("Failed to load cached follower targets.");

                Plugin.Log.Error(ex);

                if (ex is JsonSerializationException)
                {
                    Plugin.Log.Error($"Deleting malformed file " + $"\"{HelpfulPaths.TARGET_DATA}\".");

                    File.Delete(HelpfulPaths.TARGET_DATA);
                }

                return null;
            }
        }

        private static List<CustomTarget> ParseClanTargets(string clanJson)
        {
            if (string.IsNullOrWhiteSpace(clanJson))
                return [];

            try
            {
                JToken? data = JToken.Parse(clanJson)["data"];

                if (data is null)
                    return [];

                List<CustomTarget> targets =
                [
                    .. data.Children()
                        .Select(player =>
                        {
                            long id = player.Value<long?>("id") ?? 0;

                            return new CustomTarget(
                                player.Value<string>("name") ?? "Unknown",
                                id,
                                player.Value<int?>("rank") ?? -1
                            );
                        })
                        .Where(target => target.ID > 0),
                ];

                targets.Sort(CompareCustomTargets);
                return targets;
            }
            catch (Exception ex)
            {
                Plugin.Log.Error($"Failed to parse clan target data:\n{ex}");

                return [];
            }
        }

        public static async Task<(string Data, string PlayerName)> RequestClan(string playerId)
        {
            try
            {
                (bool success, HttpContent content) = await APIHandler.CallAPI_Static(
                    string.Format(HelpfulPaths.BLAPI_USERID, playerId),
                    BLAPI.Throttle
                );

                if (!success)
                    return ("", "");

                JToken player = JToken.Parse(await content.ReadAsStringAsync());

                string playerName = player.Value<string>("name") ?? "";

                string? clan = player.Value<string>("clanOrder")?.Split(',').FirstOrDefault();

                if (string.IsNullOrWhiteSpace(clan))
                    return ("", playerName);

                (success, content) = await APIHandler.CallAPI_Static(
                    string.Format(HelpfulPaths.BLAPI_CLAN_PLAYERS, clan, MAX_LIST_LENGTH),
                    BLAPI.Throttle
                );

                if (!success)
                    return ("", playerName);

                return (await content.ReadAsStringAsync(), playerName);
            }
            catch (HttpRequestException ex)
            {
                Plugin.Log.Warn("An HTTP error occurred while retrieving clan data: " + ex.Message);

                Plugin.Log.Debug(ex);
                return ("", "");
            }
        }

        /*
         * The delegate is used specifically for Steam data because accessing
         * Beat Saber's platform-user model must occur on Unity's main thread.
         */
        private static async Task<IEnumerable<CustomTarget>> RequestFollowers(
            string playerId,
            bool useSteamFriends,
            Func<Task<IReadOnlyList<string>>> getSteamFriendIds
        )
        {
            static async Task<IEnumerable<CustomTarget>> ParsePageAsync(string json)
            {
                return
                [
                    .. JToken
                        .Parse(json)
                        .Children()
                        .Select(player => new CustomTarget(
                            player.Value<string>("name") ?? "Unknown",
                            player.Value<long?>("id") ?? 0,
                            -1
                        ))
                        .Where(target => target.ID > 0),
                ];
            }

            IEnumerable<CustomTarget> fetched = await APIHandler.CalledPagedAPIFlat(
                MAX_LIST_LENGTH,
                (page, count) => string.Format(HelpfulPaths.BLAPI_FOLLOWERS, playerId, page, count),
                BLAPI.Throttle,
                ParsePageAsync
            );

            List<CustomTarget> followers = [.. fetched];

            if (!useSteamFriends)
                return followers;

            IReadOnlyList<string> steamFriends = await getSteamFriendIds();

            foreach (string id in steamFriends)
            {
                if (!long.TryParse(id, out long parsedId))
                    continue;

                if (followers.Any(target => target.ID == parsedId))
                {
                    continue;
                }

                string? json = await APIHandler
                    .GetAPI(Leaderboards.Beatleader)
                    .CallAPI_String(string.Format(HelpfulPaths.BLAPI_USERID, parsedId));

                if (string.IsNullOrWhiteSpace(json))
                    continue;

                JToken player = JToken.Parse(json);

                int rank = player.Value<int?>("rank") ?? 0;

                if (rank == 0)
                    continue;

                followers.Add(
                    new CustomTarget(
                        player.Value<string>("name") ?? "Unknown",
                        player.Value<long?>("id") ?? parsedId,
                        rank
                    )
                );
            }

            return followers;
        }

        private Task<IReadOnlyList<string>> GetSteamFriendIdsAsync()
        {
            return UnityMainThreadTaskScheduler
                .Factory.StartNew(async () =>
                {
                    IReadOnlyList<string> friends = await BS_Utils
                        .Gameplay.GetUserInfo.GetPlatformUserModel()
                        .GetUserFriendsUserIds(false);

                    return friends ?? [];
                })
                .Unwrap();
        }

        private async Task<string> GetCurrentPlayerIdAsync()
        {
            UserInfo user = await UnityMainThreadTaskScheduler
                .Factory.StartNew(BS_Utils.Gameplay.GetUserInfo.GetUserAsync)
                .Unwrap();

            return user.platformUserId;
        }

        private static int CompareTargetPairs(TargetPair first, TargetPair second) => first.Rank.CompareTo(second.Rank);

        private static int CompareCustomTargets(CustomTarget first, CustomTarget second) =>
            first.Rank.CompareTo(second.Rank);

        internal sealed class TargeterInfo(
            PluginConfig config,
            List<TargetPair> clanTargets,
            List<TargetPair> followerTargets,
            List<TargetPair> customTargets,
            HashSet<long> usedIds,
            Dictionary<string, string> idToNames
        )
        {
            private readonly PluginConfig _config = config;

            internal readonly HashSet<long> UsedIDs = usedIds;

            public IReadOnlyList<TargetPair> ClanTargets => clanTargets;

            public IReadOnlyList<TargetPair> FollowerTargets => followerTargets;

            public IReadOnlyList<TargetPair> CustomTargets => customTargets;

            /*
             * This should ideally become IReadOnlyDictionary once all current
             * callers have stopped modifying it directly.
             */
            public IReadOnlyDictionary<string, string> IDtoNames => idToNames;

            public string PlayerID { get; init; } = "";
            public string PlayerName { get; init; } = "";

            public string TargetID => _config.TargetID < 0 ? PlayerID : _config.TargetID.ToString();

            public string TargetName => _config.Target == NO_TARGET ? PlayerName : _config.Target;
        }
    }

    public readonly record struct TargetPair(string Id, int Rank);
}
