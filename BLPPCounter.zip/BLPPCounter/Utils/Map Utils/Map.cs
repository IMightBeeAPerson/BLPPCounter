using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using BeatLeader.Models;
using BLPPCounter.Helpfuls;
using BLPPCounter.Models.Base;
using BLPPCounter.Models.MapModels;
using Newtonsoft.Json.Linq;

namespace BLPPCounter.Utils.Map_Utils
{
    public class Map
    {
        public static readonly string SS_MODE_NAME = "SS_Diff";
        public static readonly string AP_MODE_NAME = "AP_Diff";

        /// <summary>
        /// Dictionary, where the key is the mode and the value is a model that contains the information for all
        /// difficulties relating to to this mode.
        /// </summary>
        private readonly Dictionary<string, MapModel> data;
        public string Hash { get; private set; }

        public Map(string hash)
        {
            Hash = hash;
            data = [];
        }

        public Map(string hash, string songId, ICacheModel data)
        {
            Hash = hash;
            this.data = [];
            Add(songId, data);
        }

        public Map(string hash, string mode, BeatmapDifficulty difficulty, string songId, ICacheModel data)
        {
            Hash = hash;
            this.data = [];
            Add(mode, difficulty, songId, data);
        }

        public void Add(string songId, ICacheModel data)
        {
            string mode = data.Mode;
            BeatmapDifficulty difficulty = data.Difficulty;
            Add(mode, difficulty, songId, data);
        }

        public void Add(string mode, BeatmapDifficulty difficulty, string songId, ICacheModel data)
        {
            if (!this.data.ContainsKey(mode))
                this.data.Add(mode, new(mode));
            this.data[mode].MapData.Add(difficulty, new(songId, difficulty, data));
        }

        public MapDiffModel? Get(string mode, BeatmapDifficulty difficulty) => data[mode]?.MapData[difficulty];

        public static BeatmapDifficulty FromValue(int value) => (BeatmapDifficulty)((value + 1) / 2 - 1);

        public static int FromDiff(BeatmapDifficulty value) => ((int)value + 1) * 2 - 1;

        public Dictionary<string, MapDiffModel> Get(BeatmapDifficulty difficulty) =>
            data.Where(kvp => kvp.Value.MapData.ContainsKey(difficulty))
                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value.MapData[difficulty]);

        public bool TryGet(string mode, BeatmapDifficulty difficulty, [NotNullWhen(true)] out MapDiffModel? value)
        {
            if (
                data.TryGetValue(mode, out MapModel? model)
                && (model?.MapData.TryGetValue(difficulty, out value) ?? false)
            )
                return true;
            value = null;
            return false;
        }

        public bool TryGet(BeatmapDifficulty difficulty, out Dictionary<string, MapDiffModel> value)
        {
            value = Get(difficulty);
            return value.Count > 0;
        }

        public string[] GetModes() => [.. data.Keys];

        public void Combine(Map other)
        {
            foreach (string mode in other.data.Keys)
                if (data.ContainsKey(mode))
                {
                    MapModel currentModel = data[mode];
                    MapModel otherModel = other.data[mode];

                    foreach (BeatmapDifficulty diff in otherModel.MapData.Keys)
                    {
                        if (!currentModel.MapData.ContainsKey(diff))
                            currentModel.MapData.Add(diff, otherModel.MapData[diff]);
                    }
                }
                else
                    data.Add(mode, new(other.data[mode]));
        }

        public static Map Combine(Map m1, Map m2)
        {
            m1.Combine(m2);
            return m1;
        }

        /*public static Map ConvertSSToTaoh(string hash, string songId, JToken SSInfo)
        {
            int diff = (int)SSInfo["difficulty"]["difficulty"];
            JToken newToken = JToken.Parse('{' + string.Format(SS_TAOH_FORMAT, SSInfo["songName"].ToString(), songId, hash, diff, SSInfo["difficulty"]["gameMode"].ToString().Replace("Solo", ""), (float)SSInfo["stars"]) + '}');
            return new Map(hash, SS_MODE_NAME, FromValue(diff), songId, newToken);
        }
        public static Map ConvertAPToTaoh(string hash, string songId, JToken APInfo)
        {
            //Plugin.Log.Info($"APInfo\n{APInfo}");
            int diff = HelpfulPaths.ReloadedDiffToDiffNum((string)APInfo["difficulty"]);
            JToken newToken = JToken.Parse('{' + string.Format(AP_TAOH_FORMAT, APInfo["songName"].ToString(), songId, hash, diff, "Standard", (float)APInfo["complexity"]) + '}');
            return new Map(hash, AP_MODE_NAME, FromValue(diff), songId, newToken);
        }*/
        public override string ToString()
        {
            string outp = $"Hash: {Hash}\n";
            foreach (string mode in data.Keys)
            {
                outp += $"---- {mode}:\n";
                foreach (BeatmapDifficulty diff in data[mode].MapData.Keys)
                {
                    outp += $"-------- {diff}: {data[mode].MapData[diff]?.Data}\n";
                }
            }
            return outp;
        }

        public override int GetHashCode()
        {
            return int.Parse(Hash, System.Globalization.NumberStyles.HexNumber);
        }
    }
}
