using BLPPCounter.CalculatorStuffs;
using BLPPCounter.Settings.SettingHandlers;
using BLPPCounter.Settings.SettingHandlers.MenuSettingHandlers;
using BLPPCounter.Settings.SettingHandlers.MenuViews;
using BLPPCounter.Utils;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Misc_Classes;
using BLPPCounter.Utils.Safety;
using Zenject;

namespace BLPPCounter.Installers
{
    internal sealed class MenuInstaller : Installer
    {
        public override void InstallBindings()
        {
            Plugin.Container = Container;

            Container.Bind<BLAPI>().AsSingle();
            Container.Bind<SSAPI>().AsSingle();
            Container.Bind<APAPI>().AsSingle();

            Container.Bind<BLCalc>().AsSingle();
            Container.Bind<SSCalc>().AsSingle();
            Container.Bind<APCalc>().AsSingle();

            Container.Bind<PathUtils>().AsSingle();

            Container.Bind<MainThreadDispatcher>().FromNewComponentOnNewGameObject().AsSingle();

            Container.BindInterfacesAndSelfTo<SettingsHandler>().FromNewComponentAsViewController().AsSingle();
            Container.BindInterfacesAndSelfTo<FormatEditorHandler>().FromNewComponentAsViewController().AsSingle();

            Container.BindInterfacesAndSelfTo<PpInfoTabHandler>().AsSingle();

            Container.Bind<LeaderboardSelector>().AsSingle();
        }
    }
}
