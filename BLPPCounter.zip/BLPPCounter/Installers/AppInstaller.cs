using BLPPCounter.Settings.Configs;
using BLPPCounter.Utils.Misc_Classes;
using Zenject;

namespace BLPPCounter.Installers
{
    internal class AppInstaller : Installer
    {
#pragma warning disable IDE0290
        private readonly PluginConfig pc;

        public AppInstaller(PluginConfig pc)
        {
            this.pc = pc;
        }

        public override void InstallBindings()
        {
            Container.BindInstance(pc).AsSingle();

            Container.BindInterfacesAndSelfTo<Targeter>().AsSingle();
        }
    }
}
