using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BLPPCounter.CalculatorStuffs;
using BLPPCounter.Counters;
using BLPPCounter.Helpfuls;
using BLPPCounter.Helpfuls.FormatHelpers;
using BLPPCounter.Models;
using BLPPCounter.Models.Base;
using BLPPCounter.Models.MapModels;
using BLPPCounter.Settings.Configs;
using BLPPCounter.Settings.SettingHandlers.MenuSettingHandlers;
using BLPPCounter.Utils;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Containers;
using BLPPCounter.Utils.Enums;
using BLPPCounter.Utils.List_Settings;
using BLPPCounter.Utils.Map_Utils;
using BLPPCounter.Utils.Misc_Classes;
using BLPPCounter.Utils.TokenParser;
using BLPPCounter.Utils.TokenParser.Printers;
using CountersPlus.Counters.Custom;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TMPro;
using Zenject;
using static GameplayModifiers;
#if NEW_VERSION
using ModestTree;
#else
using BLPPCounter.Utils.Special_Utils;
using UnityEngine;
#endif

namespace BLPPCounter
{
    public class TheCounter : BasicCustomCounter
    {
        #region Injects
#pragma warning disable CS0649, IDE0044
#if NEW_VERSION
        [Inject]
        private BeatmapLevel beatmap = null!;

        [Inject]
        private BeatmapKey beatmapDiff; // 1.37.0 and above */
#else
        [Inject]
        private IDifficultyBeatmap beatmap = null!; // 1.34.2 and below
#endif

        [Inject]
        private GameplayModifiers mods = null!;

        [Inject]
        private ScoreController sc = null!;

        [Inject]
        private BeatmapObjectManager bomb = null!;

        [Inject]
        private PlayerHeadAndObstacleInteraction wall = null!;

        private static PluginConfig pc = Plugin.Container.TryResolve<PluginConfig>();
        private LeaderboardSelector selector = Plugin.Container.TryResolve<LeaderboardSelector>();
        private PathUtils pathUtils = Plugin.Container.TryResolve<PathUtils>();
#pragma warning restore CS0649
        #endregion
        #region Static Variables
        public static Dictionary<string, Map> Data { get; private set; } = [];
        public static string DisplayName => "Main";
        private static bool dataLoaded = false,
            fullDisable = false;
        private static int leaderboardIndex = 0,
            lastLeaderboardIndex = 0;
        internal static Leaderboards Leaderboard =>
            pc.LeaderboardsInUse.Count <= leaderboardIndex ? default : pc.LeaderboardsInUse[leaderboardIndex];
        internal static bool LastLeaderboard => pc.LeaderboardsInUse.Count - 1 <= leaderboardIndex;
        internal static MapSelection LastMap;
        internal static GameplayModifiers? LastMods = null;
        public static MyCounters? theCounter { get; private set; }
        public static ReadOnlyDictionary<string, Type> StaticFunctions { get; private set; } = null!;
        public static ReadOnlyDictionary<string, Type> StaticProperties { get; private set; } = null!;
        public static Type[] ValidCounters { get; private set; } = null!;
        public static ReadOnlyDictionary<Leaderboards, string[]> ValidDisplayNames = null!;
        public static string[] DisplayNames => fullDisable ? ["There are none"] : ValidDisplayNames[Leaderboard];
        public static Dictionary<string, string> DisplayNameToCounter { get; private set; } = null!;
        private static Formatter? displayFormatter,
            targetFormatter,
            percentNeededFormatter;
        private static Printer? displayPrinter,
            targetPrinter,
            percentNeededPrinter;
        private static FormatWrapper? displayWrapper,
            targetWrapper,
            percentNeededWrapper;
        private static readonly ReadOnlyCollection<string> Labels = new([" Acc PP", " Pass PP", " Tech PP", " PP"]);
        public static string[]? CurrentLabels { get; private set; } = null;

        private static bool updateFormat;
        public static bool SettingChanged = false;
        public static bool FormatUsable => displayFormatter != null && displayPrinter != null;
        public static bool TargetUsable => targetFormatter != null && targetPrinter != null;
        public static bool PercentNeededUsable => percentNeededFormatter != null && percentNeededPrinter != null;
        public static readonly Dictionary<string, char> FormatAlias = new()
        {
            { "PP", 'x' },
            { "FCPP", 'y' },
            { "Mistake Color", 'z' },
            { "Mistakes", 'e' },
            { "Label", 'l' },
        };
        public static readonly Dictionary<string, char> TargetAlias = new() { { "Target", 't' }, { "Mods", 'm' } };
        public static readonly Dictionary<string, char> PercentNeededAlias = new()
        {
            { "Color", 'c' },
            { "Accuracy", 'a' },
            { "Tech PP", 'x' },
            { "Acc PP", 'y' },
            { "Pass PP", 'z' },
            { "PP", 'p' },
        };
        internal static readonly FormatRelation DefaultFormatRelation;
        internal static readonly FormatRelation TargetFormatRelation;
        internal static readonly FormatRelation PercentNeededFormatRelation;
        private static readonly TimeLooper TimeLooper = new();
        private static string lastTarget = Targeter.NO_TARGET;
        private static Task InitTask = Task.CompletedTask;
        private static bool CounterPaused;
        private static CancellationTokenSource? InitTaskCanceller;
        private static CancellationToken InitTaskCancelToken;
        private static Action? ForceOff;
#if !NEW_VERSION
        private static HashSet<SliderKey> sliderMap;
#endif
        #endregion
        #region Variables
        private TMP_Text? display;
        private bool enabled,
            checkedLastIndex;
        private RatingContainer ratings;
        private int notes,
            comboNotes,
            mistakes;
        private int totalHitscore,
            maxHitscore,
            fcTotalHitscore,
            fcMaxHitscore;
        private float acc,
            fcAcc;
        private string? mode,
            hash;
        private NoteData? currentNote;
        #endregion
        #region Inits & Overrides

        static TheCounter()
        {
            PluginConfig pc = Plugin.Container.Resolve<PluginConfig>();

            DefaultFormatRelation = new(
                "Main Format",
                DisplayName,
                pc.FormatSettings.DefaultTextFormat,
                str => pc.FormatSettings.DefaultTextFormat = str,
                FormatAlias,
                new Dictionary<char, string>()
                {
                    { 'x', "The unmodified PP number" },
                    { 'y', "The unmodified PP number if the map was FC'ed" },
                    { 'z', "The color used for the mistake count. It is gray if 0, red otherwise" },
                    { 'e', "The amount of mistakes made in the map. This includes bomb and wall hits" },
                    { 'l', "The label (ex: PP, Tech PP, etc)" },
                },
                FormatRelation.FormatDisplayer(SetupDisplayFormatter, FormatAlias),
                new FormatWrapper(
                    new Dictionary<char, object>()
                    {
                        { (char)1, true },
                        { (char)2, true },
                        { 'x', 543.21f },
                        { 'y', 654.32f },
                        { 'z', "red" },
                        { 'e', 2 },
                        { 'l', " PP" },
                    }
                ),
                Tokens.GLOBAL_PARAM_AMOUNT,
                new Dictionary<char, int>(1) { { 'z', 0 } },
                [FormatRelation.CreateFunc("<color={0}>{0}", "<color={0}>")],
                new Dictionary<char, IEnumerable<(string, object)>>(2)
                {
                    { 'x', new (string, object)[3] { ("MinVal", 100), ("MaxVal", 1000), ("IncrementVal", 10) } },
                    { 'y', new (string, object)[3] { ("MinVal", 100), ("MaxVal", 1000), ("IncrementVal", 10) } },
                },
                [((char)1, "Has a miss"), ((char)2, "Is bottom of text")]
            );

            TargetFormatRelation = new(
                "Target Format",
                DisplayName,
                pc.MessageSettings.TargetingMessage,
                str => pc.MessageSettings.TargetingMessage = str,
                TargetAlias,
                new Dictionary<char, string>()
                {
                    { 't', "The name of the person being targeted" },
                    { 'm', "The mods used by the person you are targeting" },
                },
                FormatRelation.FormatDisplayer(SetupTargetFormatter, TargetAlias),
                new FormatWrapper(new Dictionary<char, object>() { { 't', "Person" }, { 'm', "SF" } }),
                Tokens.GLOBAL_PARAM_AMOUNT,
                null,
                null,
                null
            );

            PercentNeededFormatRelation = new(
                "Percent Needed Format",
                DisplayName,
                pc.MessageSettings.PercentNeededMessage,
                str => pc.MessageSettings.PercentNeededMessage = str,
                PercentNeededAlias,
                new Dictionary<char, string>()
                {
                    { 'c', "Must use as a group value, and will color everything inside group" },
                    { 'a', "The accuracy needed to capture the map" },
                    { 'x', "The tech PP needed" },
                    { 'y', "The accuracy PP needed" },
                    { 'z', "The pass PP needed" },
                    { 'p', "The total PP number needed to capture the map" },
                },
                FormatRelation.FormatDisplayer(SetupPercentNeededFormatter, PercentNeededAlias),
                new FormatWrapper(
                    new Dictionary<char, object>()
                    {
                        { 'c', new Func<object>(() => "green") },
                        { 'a', "95.85" },
                        { 'x', 114.14f },
                        { 'y', 321.23f },
                        { 'z', 69.42f },
                        { 'p', 543.21f },
                        { 't', "Person" },
                    }
                ),
                Tokens.GLOBAL_PARAM_AMOUNT,
                new Dictionary<char, int>(3)
                {
                    { 'c', 0 },
                    { 'a', 1 },
                    { 't', 2 },
                },
                [
                    FormatRelation.CreateFuncWithWrapper("<color={0}>{0}", "<color={0}>"),
                    FormatRelation.CreateFunc("{0}%", "{0}"),
                    FormatRelation.CreateFunc("Targeting <color=red>{0}</color>"),
                ],
                new Dictionary<char, IEnumerable<(string, object)>>(5)
                {
                    { 'a', new (string, object)[3] { ("MinVal", 0), ("MaxVal", 100), ("IncrementVal", 1.5f) } },
                    { 'x', new (string, object)[3] { ("MinVal", 10), ("MaxVal", 1000), ("IncrementVal", 10) } },
                    { 'y', new (string, object)[3] { ("MinVal", 10), ("MaxVal", 1000), ("IncrementVal", 10) } },
                    { 'z', new (string, object)[3] { ("MinVal", 10), ("MaxVal", 1000), ("IncrementVal", 10) } },
                    { 'p', new (string, object)[3] { ("MinVal", 100), ("MaxVal", 1000), ("IncrementVal", 10) } },
                },
                null,
                [('c', ValueListInfo.ValueType.Color)]
            );
        }

        internal static void InitCounterStatic()
        {
            PluginConfig? pc = Plugin.Container.TryResolve<PluginConfig>();

            if (pc is null)
            {
                Plugin.Log.Warn(
                    "PluginConfig is null in InitCounterStatic. This is likely due to the plugin being disabled or not fully initialized yet."
                );
                return;
            }

            displayWrapper = new FormatWrapper(
                (typeof(bool), (char)1),
                (typeof(bool), (char)2),
                (typeof(float), 'x'),
                (typeof(string), 'z'),
                (typeof(string), 'l'),
                (typeof(float), 'y'),
                (typeof(int), 'e')
            );
            percentNeededWrapper = new FormatWrapper(
                (typeof(string), 'c'),
                (typeof(float), 'a'),
                (typeof(float), 'x'),
                (typeof(float), 'y'),
                (typeof(float), 'z'),
                (typeof(float), 'p')
            );
            targetWrapper = new FormatWrapper((typeof(string), 't'), (typeof(string), 'm'));

            updateFormat = false;
            static void PropChanged(object o, PropertyChangedEventArgs args)
            {
                updateFormat = true;
            }
            SettingsHandler.NewInstance += (handler) => handler.PropertyChanged += PropChanged;
            SettingsHandler.Instance.PropertyChanged += PropChanged;
            LeaderboardSettingsHandler.Instance.LeaderboardUpdated += () => lastLeaderboardIndex = leaderboardIndex = 0; // Plugin.Log.Info($"LeaderboardIndex: {leaderboardIndex}, Leaderboard: {Leaderboard}"); };

            StaticFunctions = new ReadOnlyDictionary<string, Type>(
                new Dictionary<string, Type>() { { "InitFormat", typeof(bool) }, { "ResetFormat", typeof(void) } }
            );
            StaticProperties = new ReadOnlyDictionary<string, Type>(
                new Dictionary<string, Type>()
                {
                    { "DisplayName", typeof(string) },
                    { "OrderNumber", typeof(int) },
                    { "DisplayHandler", typeof(string) },
                    { "ValidLeaderboards", typeof(Leaderboards) },
                }
            );

            GetMethodFromTypes("InitFormat", typeof(TheCounter)); //Call this by itself because it is not a chooseable counter.

            try
            {
                Type?[] validTypes = GetValidCounters();
                Dictionary<string, object> methodOutp = GetMethodFromTypes("InitFormat", validTypes!);
                for (int i = validTypes.Length - 1; i >= 0; i--)
                {
                    if (validTypes[i] is not null and Type t && methodOutp[t.FullName] is bool v)
                        if (!v)
                            validTypes[i] = null;
                }
                ValidCounters = [.. validTypes.Where(a => a is not null).Select(a => a!)];
                Dictionary<string, object> propertyOutp = GetPropertyFromTypes("DisplayName", ValidCounters);
                //foreach (var toCheck in GetPropertyFromTypes("DisplayHandler", ValidCounters).Where(a => (a.Value as string).Equals(DisplayName)))
                //{
                //    ValidCounters[ValidCounters.IndexOf(ValidCounters.First(a => a.Name.Equals(propertyOutp[toCheck.Key] as string)))] = null;
                //    propertyOutp.Remove(toCheck.Key);
                //}
                ValidCounters = [.. ValidCounters.Where(a => a != null)];
                DisplayNameToCounter = [];
                Dictionary<string, string> counterToDisplayName = [];
                foreach (KeyValuePair<string, object> val in propertyOutp)
                    if (val.Value is string name)
                    {
                        DisplayNameToCounter.Add(name, val.Key);
                        counterToDisplayName.Add(val.Key, name);
                    }
                Dictionary<int, string> propertyOrder = GetPropertyFromTypes("OrderNumber", ValidCounters)
                    .ToDictionary(x => (int)x.Value, x => x.Key);
                List<string> displayNames = [];

                IOrderedEnumerable<int> sortedOrderNumbers = propertyOrder.Keys.OrderBy(x => x);
                foreach (int i in sortedOrderNumbers)
                    if (propertyOutp[propertyOrder[i]] is not null and string s)
                        displayNames.Add(s);

                Dictionary<string, Leaderboards> hold =
                [
                    with(
                        GetPropertyFromTypes("ValidLeaderboards", ValidCounters)
                            .Select(kvp => new KeyValuePair<string, Leaderboards>(kvp.Key, (Leaderboards)kvp.Value))
                    ),
                ];
                Dictionary<Leaderboards, string[]> DNames = [];

                foreach (Leaderboards l in Enum.GetValues(typeof(Leaderboards)))
                    DNames[l] = [.. hold.Where(kvp => (kvp.Value & l) > 0).Select(kvp => kvp.Key)];

                IEnumerable<Leaderboards> keys = Enum.GetValues(typeof(Leaderboards)).Cast<Leaderboards>();
                foreach (Leaderboards l in keys)
                {
                    HashSet<string> ls = [.. DNames[l].Select(n => counterToDisplayName[n])];
                    DNames[l] = [.. displayNames.Where(ls.Contains)];
                }

                ValidDisplayNames = new ReadOnlyDictionary<Leaderboards, string[]>(DNames);
            }
            catch (Exception e)
            {
                Plugin.Log.Error("Oh no! The static check for counters broke somehow :(");
                Plugin.Log.Error(e.ToString());
                return;
            }

            if (DisplayNames.Length == 0)
            {
                if (ValidDisplayNames.Values.Where(arr => arr.Length > 0).Count() > 0)
                {
                    pc.LeaderboardsInUse.Add(ValidDisplayNames.Where(kvp => kvp.Value.Length > 0).First().Key);
                    Plugin.Log.Warn(
                        "There was no leaderboards added which causes issues. Added a working leaderboard."
                    );
                }
                else
                    goto Fail;
            }
            if (DisplayNames.Length > 0)
            {
                if (!DisplayNames.Contains(pc.PPType))
                    pc.PPType = DisplayNames[0];
                goto End;
            }
        Fail:
            Plugin.Log.Critical(
                "No counter is in working order!!! Shutting down this counter as it will only cause issues."
            );
            fullDisable = true;
        End:
            LoadSomeTaohableData();
        }

        public static bool InitFormat()
        {
            PluginConfig pc = Plugin.Container.TryResolve<PluginConfig>();

            InitDisplayFormat(pc.FormatSettings.DefaultTextFormat);
            InitTarget(pc.MessageSettings.TargetingMessage);
            InitPercentNeeded(pc.MessageSettings.PercentNeededMessage);
            return true;
        }

        public static void ResetFormat()
        {
            displayPrinter = null;
            displayFormatter = null;
            targetPrinter = null;
            targetFormatter = null;
            percentNeededPrinter = null;
            percentNeededFormatter = null;
        }

        public override void CounterDestroy()
        {
            Plugin.Log.Debug($"There were {notes} note(s) handled.");
            try
            {
                ChangeNotifiers(false);
                if (enabled)
                {
                    lastLeaderboardIndex = leaderboardIndex;
                    if (pc.UpdateAfterTime)
#pragma warning disable CS4014 // Do not await this call or you deadlock the main thread you dingus
                        TimeLooper.End();
#pragma warning restore CS4014
                    theCounter?.CounterComplete(acc, fcAcc, notes, mistakes);
                }
                if (!InitTask.IsCompleted)
                {
                    Plugin.Log.Warn("Player exited map faster than the init task could complete. Cancelling.");
                    InitTaskCanceller?.Cancel();
                    try
                    {
                        InitTask.GetAwaiter().GetResult();
                    }
                    catch (Exception e)
                    {
                        Plugin.Log.Warn($"Error waiting for InitTask\n{e}");
                    }
                }
                InitTaskCanceller?.Dispose();
            }
            catch (Exception e)
            {
                Plugin.Log.Error("There was an issue turning the counter off!");
                Plugin.Log.Debug(e);
                theCounter = null;
            }
        }

        public override void CounterInit()
        {
            pc = Plugin.Container.TryResolve<PluginConfig>();

            enabled = checkedLastIndex = CounterPaused = false;
            leaderboardIndex = lastLeaderboardIndex;
            ForceOff = () => ForceTurnOff();
            if (fullDisable || Leaderboard == default)
                return;
            notes = comboNotes = mistakes = 0;
            totalHitscore = maxHitscore = fcTotalHitscore = fcMaxHitscore = 0;
            acc = fcAcc = 0f;
#if !NEW_VERSION
            sliderMap = [];
#endif
            ChangeNotifiers(true);
            display = CanvasUtility.CreateTextFromSettings(Settings);
            display.fontSize = (float)pc.FontSize;
            display.text = "Loading...";
            InitTaskCanceller = new CancellationTokenSource();
            InitTaskCancelToken = InitTaskCanceller.Token;
            InitTask = Task.Run(async () => await AsyncCounterInit(InitTaskCancelToken), InitTaskCancelToken);
        }

        private async Task AsyncCounterInit(CancellationToken ct, bool ignoreLast = false)
        {
            if (!dataLoaded)
            {
                Data = [];
                InitData();
            }
            if (leaderboardIndex == lastLeaderboardIndex && checkedLastIndex)
                goto Failed;
            Plugin.Log.Info("Attempting to load " + Leaderboard + "...");
            try
            {
                if (!dataLoaded && hash is not null)
                    await APIHandler.GetAPI(Leaderboard).AddMap(Data, hash, ct);

                enabled = SetupMapData(ct);

                if (ct.IsCancellationRequested)
                    return;

                if (enabled)
                {
#if NEW_VERSION
                    hash = beatmap.levelID.Split('_')[2]; // 1.37.0 and above
#else
                    hash = beatmap.level.levelID.Split('_')[2]; // 1.34.2 and below
#endif
                    if (hash[^3..].ToLower().Equals("wip"))
                    {
                        Plugin.Log.Warn("WIP Map, counter will disable.");
                        ForceTurnOff();
                        return;
                    }
                    if (
                        !LastMap.Equals(default)
                        && !hash.Equals(LastMap.Hash)
                        && !ignoreLast
                        && lastLeaderboardIndex != 0
                        && lastLeaderboardIndex == leaderboardIndex
                    )
                    {
                        Plugin.Log.Info("Ignoring last leaderboard used since the map has changed.");
                        leaderboardIndex = 0;
                        await AsyncCounterInit(ct, true);
                        return;
                    }
                    bool counterChange = !SettingChanged && (!theCounter?.Name.Equals(pc.PPType) ?? false);
                    if (counterChange)
                        if (
                            (
                                GetPropertyFromTypes("DisplayHandler", theCounter!.GetType()).Values.First() as string
                            )?.Equals(DisplayName) ?? false
                        )
                            //Need to recall this one so that it implements the current counter's wants properly
                            InitDisplayFormat(pc.FormatSettings.DefaultTextFormat);
                    //Plugin.Log.Info($"CounterChange = {counterChange}, SettingChanged = {SettingChanged}\nNULL CHECKS\nLast map: {LastMap.Equals(default)}, hash: {hash is null}, pc: {pc is null}, PPType: {pc?.PPType is null}, lastTarget: {lastTarget is null}, Target: {pc.Target is null}");
                    if (
                        theCounter is null
                        || SettingChanged
                        || counterChange
                        || LastMap.Equals(default)
                        || !hash.Equals(LastMap.Hash)
                        || !lastTarget.Equals(pc.Target)
                    )
                    {
                        Map? m = await GetMap(
                            hash,
                            mode!,
                            Leaderboard,
                            pc.UseUnranked && Leaderboard == Leaderboards.Beatleader,
                            ct
                        );

                        if (m is null)
                        {
                            Plugin.Log.Warn("The map returned is null, making it unusable.");
                            goto Failed;
                        }

                        if (ct.IsCancellationRequested)
                            return;
#if NEW_VERSION
                        MapSelection ms = new(m, beatmapDiff.difficulty, mode!, ratings, mods.songSpeed); // 1.37.0 and above
#else
                        MapSelection ms = new(m, beatmap.difficulty, mode!, ratings, mods.songSpeed); // 1.34.2 and below
#endif
                        if (!ms.IsUsable)
                        {
                            Plugin.Log.Warn("The status of this map marks it as unusable.");
                            goto Failed;
                        }
                        LastMap = ms;
                        LastMods = mods;
                        if (!InitCounter())
                        {
                            Plugin.Log.Warn("Counter somehow failed to init. Weedoo weedoo weedoo weedoo.");
                            goto Failed;
                        }
                        SettingChanged = false;

                        if (Leaderboard == Leaderboards.Beatleader)
                            await BLCalc.Instance.SetCurve(LastMap.MapData.songId, LastMap.MapSpeed);
                    }
                    else if (!APIAvoidanceMode())
                        goto Failed;

                    lastTarget = pc.Target;

                    if (updateFormat)
                    {
                        theCounter.UpdateFormat();
                        updateFormat = false;
                    }

                    if (pc.UpdateAfterTime)
                        SetTimeLooper();

                    SetLabels();
                    display?.SetText("Loaded!");
                    Plugin.Log.Debug("Counter loaded successfully.");

                    if (pc.UpdateAfterTime)
                        await TimeLooper.Start();
                    else if (notes < 1)
                        theCounter.UpdateCounter(1, 0, 0, 1, null);

                    return;
                }
                else
                    Plugin.Log.Warn("Maps failed to load, most likely unranked.");
            }
            catch (Exception e)
            {
                Plugin.Log.Error($"The counter failed to be initialized: {e.Message}\nSource: {e.Source}");

                if (e is KeyNotFoundException)
                    Plugin.Log.Error($"Data dictionary length: {Data.Count}");

                Plugin.Log.Debug(e);

                if (LastLeaderboard)
                    ForceTurnOff();
            }
        Failed:
            if (!LastLeaderboard || (!checkedLastIndex && pc.LeaderboardsInUse.Count > 1))
            {
                if (leaderboardIndex == lastLeaderboardIndex && !checkedLastIndex)
                {
                    leaderboardIndex = lastLeaderboardIndex == 0 ? 1 : 0;
                    checkedLastIndex = true;
                }
                else
                    leaderboardIndex +=
                        leaderboardIndex + 1 == lastLeaderboardIndex && !checkedLastIndex && !ignoreLast ? 2 : 1;
                if (ct.IsCancellationRequested)
                    return;
                await AsyncCounterInit(ct, ignoreLast);
            }
            else
                ForceTurnOff();
        }
        #endregion
        #region Event Calls
        private void OnNoteScored(ScoringElement scoringElement)
        {
            try
            {
                OnNoteScoredInternal(scoringElement);
            }
            catch (Exception e)
            {
                Plugin.Log.Error("The counter encountered a fatal error, shutting down.");
                ForceTurnOff("Fatal error!\nPlease report this!");
                Plugin.Log.Debug(e);
                if (e is NullReferenceException || e is ArgumentNullException)
                    Plugin.Log.Debug(
                        $"NULL CHECKS: theCounter null? {theCounter is null} || scoringElement null? {scoringElement is null} || InitTask is null? {InitTask is null} || TimeLooper is null? {TimeLooper is null} || scoringElement.NoteData is null? {scoringElement?.noteData is null}"
                    );
            }
            finally
            {
                if (pc.UpdateAfterTime)
                    TimeLooper?.Resume();
            }
        }

        private void OnNoteScoredInternal(ScoringElement scoringElement)
        {
            if (scoringElement.noteData.gameplayType == NoteData.GameplayType.Bomb)
                return;
            NoteData.ScoringType st = scoringElement.noteData.scoringType;
            currentNote = scoringElement.noteData;
            if (st == NoteData.ScoringType.Ignore)
                goto Finish; //if scoring type is Ignore, skip this function
            notes++;
            if (st != NoteData.ScoringType.NoScore)
                comboNotes++;

            int cutScore = scoringElement.cutScore,
                maxCutScore = scoringElement.maxPossibleCutScore;
            int offset = HandleWeirdNoteBehaviour(currentNote, maxCutScore);
            if (offset != 0)
            {
                cutScore += offset;
                maxCutScore += offset;
            }

            maxHitscore += maxCutScore * HelpfulMath.MultiplierForNote(notes);
            if (cutScore > 0)
            {
                fcMaxHitscore += maxCutScore * HelpfulMath.MultiplierForNote(notes);
                totalHitscore += cutScore * HelpfulMath.MultiplierForNote(comboNotes);
                fcTotalHitscore += cutScore * HelpfulMath.MultiplierForNote(notes);
            }
            else
                OnMiss();
            acc = (float)totalHitscore / maxHitscore;
            fcAcc = (float)fcTotalHitscore / fcMaxHitscore;
            //Plugin.Log.Info($"Note #{notes} ({st}): {cutScore} / {maxCutScore}" + (offset != 0 ? $" (shifted max from {scoringElement.maxPossibleCutScore})" : ""));
        Finish:
            if (!InitTask.IsCompleted || CounterPaused)
                return;

            theCounter!.SoftUpdate(acc, notes, mistakes, fcAcc, currentNote);

            if (!pc.UpdateAfterTime)
                theCounter.UpdateCounter(acc, notes, mistakes, fcAcc, currentNote);
        }

#if !NEW_VERSION
        private void OnSliderSpawn(SliderController sc)
        {
            if (!sc.sliderData.hasHeadNote)
                return;
            sliderMap.Add(KeyFromSliderData(sc.sliderData, true));
        }
#endif

        private void OnBombHit(NoteController nc, in NoteCutInfo nci)
        {
            if (nc.noteData.gameplayType == NoteData.GameplayType.Bomb)
                OnMiss();
        }

        private void OnWallHit(ObstacleController oc)
        {
            OnMiss();
        }

        private void OnMiss()
        {
            if (notes == 0)
                return;
            comboNotes = HelpfulMath.DecreaseMultiplier(comboNotes);
            mistakes++;
        }

        private void SetTimeLooper()
        {
            TimeLooper.DelayMs = (int)(pc.UpdateTime * 1000);
            int currentNotes = 0;
            TimeLooper.SetAction(() =>
            {
                if (currentNotes == notes)
                    return true;
                theCounter?.UpdateCounter(acc, notes, mistakes, fcAcc, currentNote);
                currentNotes = notes;
                return false;
            });
        }
        #endregion
        #region Helper Methods
        public static int HandleWeirdNoteBehaviour(NoteData note, int maxCutscore) =>
            ScoreModel.GetNoteScoreDefinition(HandleWeirdNoteBehaviour(note)).maxCutScore - maxCutscore;

        public static NoteData.ScoringType HandleWeirdNoteBehaviour(NoteData note)
        {
#if NEW_VERSION
            if (note.gameplayType == NoteData.GameplayType.BurstSliderHead && note.isArcHead)
#endif
#if NEWER_VERSION
            return note.isArcTail ? NoteData.ScoringType.ArcHeadArcTail : NoteData.ScoringType.ArcHead;
#elif NEW_VERSION
                return note.isArcTail
                    ? (NoteData.ScoringType)BLCalc.ExtendedScoringType.ArcHeadArcTail
                    : (NoteData.ScoringType)2;
#else
            bool isSliderHead = false;
            SliderKey sk = KeyFromNoteData(note);
            if (sliderMap.Contains(sk))
            {
                sliderMap.Remove(sk);
                isSliderHead = true;
            }
            if (note.gameplayType == NoteData.GameplayType.BurstSliderHead && isSliderHead)
                note.ChangeToSliderHead();
#endif
            return note.scoringType;
        }

        private void ChangeNotifiers(bool a)
        {
            if (a)
            {
                sc.scoringForNoteFinishedEvent += OnNoteScored;
                wall.headDidEnterObstacleEvent += OnWallHit;
                bomb.noteWasCutEvent += OnBombHit;
#if !NEW_VERSION
                bomb.sliderWasSpawnedEvent += OnSliderSpawn;
#endif
            }
            else
            {
                sc.scoringForNoteFinishedEvent -= OnNoteScored;
                wall.headDidEnterObstacleEvent -= OnWallHit;
                bomb.noteWasCutEvent -= OnBombHit;
#if !NEW_VERSION
                bomb.sliderWasSpawnedEvent -= OnSliderSpawn;
#endif
            }
        }

#if !NEW_VERSION
        private static SliderKey KeyFromNoteData(NoteData nd) =>
            new(Mathf.RoundToInt(nd.time * 1000f), nd.lineIndex, nd.noteLineLayer, nd.colorType, nd.cutDirection);

        private static SliderKey KeyFromSliderData(SliderData sd, bool useHead) =>
            useHead
                ? new SliderKey(
                    Mathf.RoundToInt(sd.time * 1000f),
                    sd.headLineIndex,
                    sd.headLineLayer,
                    sd.colorType,
                    sd.headCutDirection
                )
                : new SliderKey(
                    Mathf.RoundToInt(sd.tailTime * 1000f),
                    sd.tailLineIndex,
                    sd.tailLineLayer,
                    sd.colorType,
                    sd.tailCutDirection
                );
#endif

        internal void ForceTurnOff(string errorText = "")
        {
            enabled = false;
            display?.text = errorText;
            ChangeNotifiers(false);
            theCounter = null;
        }

        internal static void CancelCounter() => ForceOff?.Invoke();

        public static void ClearCounter() => LastMap = default;

        public static void ForceLoadMaps()
        {
            if (dataLoaded)
                return;
            Data = [];
            InitData();
        }

        internal static async Task<Map?> GetMap(
            string hash,
            string? mode,
            APIHandler? api = null,
            bool forceHunt = false,
            CancellationToken ct = default
        )
        {
            if (!dataLoaded)
                ForceLoadMaps();
            if (!Data.TryGetValue(hash, out Map m) || !m.GetModes().Contains(mode))
            {
                if ((!pc.HuntLoads && !forceHunt) || api is null)
                {
                    Plugin.Log.Warn("Map not in cache.");
                    return m;
                }
                Plugin.Log.Warn("Map not in cache, attempting API call to get map data...");
                await api.AddMap(Data, hash, ct);
                if (!Data.TryGetValue(hash, out m))
                    return null;
            }
            return m;
        }

        public static async Task<Map?> GetMap(
            string hash,
            string? mode,
            Leaderboards leaderboard,
            bool forceHunt = false,
            CancellationToken ct = default
        ) =>
            await GetMap(
                hash,
                mode,
                Plugin.Container.TryResolve<LeaderboardSelector>().GetAPI(leaderboard),
                forceHunt,
                ct
            );

        public MapSelection GetDifficulty(
            Map m,
            BeatmapDifficulty diff,
            Leaderboards leaderboard,
            string mode = "Standard",
            GameplayModifiers? mods = null,
            bool quiet = false
        )
        {
            MapDiffModel? diffData = m.Get(mode, diff);
            if (diffData is null || !SetupMapData(diffData.Data, leaderboard, out float[]? ratings, mods, quiet))
                return default;
            return new MapSelection(m, diff, mode, mods?.songSpeed ?? SongSpeed.Slower, leaderboard, ratings!);
        }

        public static string SelectMode(string? mainMode, Leaderboards leaderboard) =>
            leaderboard switch
            {
                Leaderboards.Scoresaber => Map.SS_MODE_NAME,
                Leaderboards.Accsaber => Map.AP_MODE_NAME,
                _ => mainMode ?? "Standard",
            };

        private static void InitDisplayFormat(string format)
        {
            if (displayWrapper is null)
            {
                Plugin.Log.Warn("Cannot init display when the display wrapper is null!");
                return;
            }

            displayFormatter = SetupDisplayFormatter(format, displayWrapper, FormatAlias);

            displayPrinter = displayFormatter.GetOutput();
        }

        internal static Formatter SetupDisplayFormatter(
            string format,
            FormatWrapper values,
            Dictionary<string, char>? alias = null
        )
        {
            Formatter outp = new(TokenParser.ParseTokens(format, alias), values);

            outp.SurroundToken('z', "$", "</color>");
            outp.PromiseValueForTokens();

            return outp;
        }

        private static string DisplayFormatter(
            bool fc,
            bool totPp,
            float pp,
            float fcpp,
            string mistakeColor,
            int mistakes,
            string label
        )
        {
            displayWrapper!.SetValues(
                ((char)1, fc),
                ((char)2, totPp),
                ('x', pp),
                ('z', mistakeColor),
                ('l', label),
                ('y', fcpp),
                ('e', mistakes)
            );
            return displayPrinter!.Print();
        }

        private static void InitTarget(string format)
        {
            if (targetWrapper is null)
            {
                Plugin.Log.Warn("Cannot init target when the target wrapper is null!");
                return;
            }

            targetFormatter = SetupTargetFormatter(format, targetWrapper, TargetAlias);

            targetPrinter = targetFormatter.GetOutput();
        }

        internal static Formatter SetupTargetFormatter(
            string format,
            FormatWrapper values,
            Dictionary<string, char>? alias = null
        )
        {
            Formatter outp = new(TokenParser.ParseTokens(format, alias), values);

            outp.PromiseValueForTokens();

            return outp;
        }

        public static string? TargetFormatter(string name, string mods)
        {
            if (targetWrapper is null || targetFormatter is null)
                return null;
            targetWrapper!.SetValues(('t', name), ('m', mods));
            return targetPrinter!.Print();
        }

        private static void InitPercentNeeded(string format)
        {
            if (percentNeededWrapper is null)
            {
                Plugin.Log.Warn("Cannot init percent needed when the percent needed wrapper is null!");
                return;
            }

            percentNeededFormatter = SetupPercentNeededFormatter(format, percentNeededWrapper, PercentNeededAlias);

            percentNeededPrinter = percentNeededFormatter.GetOutput();
        }

        internal static Formatter SetupPercentNeededFormatter(
            string format,
            FormatWrapper values,
            Dictionary<string, char>? alias = null
        )
        {
            Formatter outp = new(TokenParser.ParseTokens(format, alias), values);

            outp.SurroundToken('c', "$", "</color>");
            outp.PromiseValueForTokens();

            return outp;
        }

        public static string? PercentNeededFormatter(
            string colorFunc,
            float acc,
            float passPP,
            float accPP,
            float techPP,
            float pp
        )
        {
            percentNeededWrapper!.SetValues(
                ('c', colorFunc),
                ('a', acc),
                ('x', techPP),
                ('y', accPP),
                ('z', passPP),
                ('p', pp)
            );
            return percentNeededPrinter!.Print();
        }

        private static Type[] GetValidCounters()
        {
            List<Type> counters = [];
            //The line below adapted from: https://stackoverflow.com/questions/26733/getting-all-types-that-implement-an-interface
            IEnumerable<Type> types = Assembly
                .GetExecutingAssembly()
                .GetTypes()
                .Where(mytype => mytype.BaseType?.Equals(typeof(MyCounters)) ?? false);
            foreach (Type t in types)
            {
                MethodInfo[] methods = t.GetMethods(BindingFlags.Public | BindingFlags.Static);
                Dictionary<string, Type> Funcs = new Dictionary<string, Type>(StaticFunctions);
                foreach (MethodInfo m in methods)
                    if (Funcs.ContainsKey(m.Name))
                        if (m.ReturnParameter.ParameterType.Equals(Funcs[m.Name]))
                        {
                            Funcs.Remove(m.Name);
                            if (Funcs.Count == 0)
                                break;
                        }
                        else
                            break;
                if (Funcs.Count != 0)
                    continue;
                PropertyInfo[] properties = t.GetProperties(BindingFlags.Public | BindingFlags.Static);
                Dictionary<string, Type> Vars = new Dictionary<string, Type>(StaticProperties);
                foreach (PropertyInfo p in properties)
                    if (Vars.ContainsKey(p.Name))
                        if (p.PropertyType == Vars[p.Name])
                        {
                            if (!p.CanRead)
                                continue;
                            Vars.Remove(p.Name);
                            if (Vars.Count == 0)
                                break;
                        }
                        else
                            break;
                if (Vars.Count == 0)
                    counters.Add(t);
                else
                {
                    FieldInfo[] fields = t.GetFields(BindingFlags.Public | BindingFlags.Static);
                    foreach (FieldInfo f in fields)
                        if (Vars.ContainsKey(f.Name))
                            if (f.FieldType == Vars[f.Name])
                            {
                                if (f.IsInitOnly)
                                    Vars.Remove(f.Name);
                                else
                                    Plugin.Log.Warn(
                                        $"For counter {t.Name}, they have the valid variable {f.Name} but need to set it to readonly."
                                    );
                                if (Vars.Count == 0)
                                    break;
                            }
                            else
                                break;
                    if (Vars.Count == 0)
                        counters.Add(t);
                }
            }
            return [.. counters];
        }

        private static Dictionary<string, object> GetMethodFromTypes(string methodName, params Type[] types) =>
            GetMethodFromTypes(methodName, BindingFlags.Public | BindingFlags.Static, types);

        private static Dictionary<string, object> GetMethodFromTypes(
            string methodName,
            BindingFlags flags,
            params Type[] types
        )
        {
            Dictionary<string, object> outp = [];
            foreach (Type t in types)
            {
                MethodInfo method = t.GetMethods(flags).First(a => a.Name.Equals(methodName));
                outp.Add(t.FullName, method.Invoke(null, null));
            }
            return outp;
        }

        private static Dictionary<string, object> GetPropertyFromTypes(string propertyName, params Type[] types) =>
            GetPropertyFromTypes(propertyName, BindingFlags.Public | BindingFlags.Static, types);

        private static Dictionary<string, object> GetPropertyFromTypes(
            string propertyName,
            BindingFlags flags,
            params Type[] types
        )
        {
            bool hasFlags = flags != 0;
            Dictionary<string, object> outp = [];
            foreach (Type t in types)
            {
                PropertyInfo method = (hasFlags ? t.GetProperties(flags) : t.GetProperties()).First(a =>
                    a.Name.Equals(propertyName)
                );
                outp.Add(t.FullName, method.GetValue(null));
            }
            return outp;
        }

        private void SetLabels()
        {
            CurrentLabels = new string[selector.GetCalc(Leaderboard).DisplayRatingCount];
            string predicate = pc.LeaderInLabel ? selector.GetCalc(Leaderboard).Label : "";
            for (int i = 0; i < CurrentLabels.Length; i++)
                if (pc.LeaderInLabel && Leaderboard != Leaderboards.Accsaber)
                    CurrentLabels[i] = predicate + Labels[CurrentLabels.Length == 1 ? 3 : i];
                else
                    CurrentLabels[i] = predicate;
        }
        #endregion
        #region Init
        [MemberNotNullWhen(true, nameof(theCounter))]
        private bool InitCounter(CancellationToken ct = default)
        {
            try
            {
                if (display is null)
                    return false;

                MyCounters? outpCounter = InitCounter(pc.PPType, display, ct);

                if (outpCounter is null)
                    return false;

                theCounter = outpCounter;
                return true;
            }
            catch (Exception e)
            {
                Plugin.Log.Error("There was an error making the counter:\n" + e);
                return false;
            }
        }

        public static MyCounters? InitCounter(string name, TMP_Text display, CancellationToken ct = default)
        {
            if (!DisplayNameToCounter.TryGetValue(name, out string displayName))
            {
                Plugin.Log.Error(
                    $"Oh No! Name '{name}' was not a valid displayName!\nValid display names: {HelpfulMisc.Print(DisplayNameToCounter.Keys)}"
                );
                return null;
            }
            Type counterType =
                ValidCounters.FirstOrDefault(a => a.FullName.Equals(displayName))
                ?? throw new ArgumentException(
                    $"Name '{displayName}' is not a counter! Valid counter names are:\n{string.Join("\n", ValidCounters as IEnumerable<Type>)}"
                );
            if (
                GetPropertyFromTypes("ValidLeaderboards", counterType)
                    .TryGetValue(counterType.FullName, out object info) && info is Leaderboards valid
            )
            {
                if ((valid & Leaderboard) == Leaderboards.None)
                {
                    Plugin.Log.Warn("The leaderboard selected is not valid for the given counter type.");
                    return null;
                }
            }
            else
            {
                Plugin.Log.Error("There was an error with reading the leaderboard type of the counter.");
                return null;
            }
            try
            {
                MyCounters outp = (MyCounters)Activator.CreateInstance(counterType, display, LastMap, ct);
                outp.UpdateFormat();
                return outp;
            }
            catch (TargetInvocationException e)
            {
                if (e.InnerException is TaskCanceledException)
                {
                    Plugin.Log.Warn("Creation of the counter failed due to cancellation token being invoked.");
                    Plugin.Log.Debug(e);
                    return null;
                }
                else
                    throw e;
            }
        }

        private bool APIAvoidanceMode()
        {
            if (mode is null || display is null || theCounter is null)
                return false;

            Plugin.Log.Debug("API Avoidance mode is active.");
#if NEW_VERSION
            MapSelection thisMap = new(Data[LastMap.Hash], beatmapDiff.difficulty, mode, ratings, mods.songSpeed); // 1.37.0 and above
#else
            MapSelection thisMap = new(Data[LastMap.Hash], beatmap.difficulty, mode, ratings, mods.songSpeed); // 1.34.2 and below
#endif
            if (!thisMap.IsUsable)
                return false;
            //Plugin.Log.Debug($"Last Map\n-------------------\n{LastMap}\n-------------------\nThis Map\n-------------------\n{thisMap}\n-------------------");
            bool ratingDiff,
                diffDiff;
            (ratingDiff, diffDiff) = thisMap.GetDifference(LastMap);

            if (Leaderboard == Leaderboards.Beatleader && (ratingDiff || diffDiff))
                BLCalc.Instance.SetCurve(LastMap.MapData.songId, LastMap.MapSpeed).GetAwaiter().GetResult();

            //Plugin.Log.Debug($"DID CHANGE || Rating: {ratingDiff}, Difficulty: {diffDiff}");
            if (diffDiff)
                theCounter.ReinitCounter(display, thisMap);
            else if (ratingDiff)
                theCounter.ReinitCounter(display, ratings);
            else
                theCounter.ReinitCounter(display);
            LastMap = thisMap;
            return true;
        }

        internal void ReplaceCurrentCounter(string newCounter, TMP_Text display)
        {
            try
            {
                if (pc.UpdateAfterTime)
                    TimeLooper.Pause();
                CounterPaused = true;
                MyCounters? outpCounter = InitCounter(newCounter, display);
                if (outpCounter is null)
                {
                    CancelCounter();
                    Plugin.Log.Error("Error changing counter, new counter is null.");
                    return;
                }
                theCounter = outpCounter;
                CounterPaused = false;
                if (pc.UpdateAfterTime)
                    TimeLooper.Resume();
            }
            catch (Exception e)
            {
                Plugin.Log.Error("Error changing counter:\n" + e);
                CancelCounter();
            }
        }

        private static void InitData(bool loadOnlySS = false, bool doNotLoop = false)
        {
            dataLoaded = false;
            if (!loadOnlySS && File.Exists(HelpfulPaths.BL_CACHE_FILE))
            {
                try
                {
                    List<BlCacheEntry>? results = JsonConvert
                        .DeserializeObject<BlCache>(File.ReadAllText(HelpfulPaths.BL_CACHE_FILE))
                        ?.Entries;

                    if (results is null)
                    {
                        Plugin.Log.Warn("BL Cache file was empty or invalid.");
                        return;
                    }

                    foreach (BlCacheEntry result in results)
                    {
                        Map map = new(result.SongInfo.Hash.ToUpper(), result.LeaderboardId, result);
                        if (Data.ContainsKey(map.Hash))
                            Data[map.Hash].Combine(map);
                        else
                            Data[map.Hash] = map;
                    }
                }
                catch (Exception e)
                {
                    Plugin.Log.Warn("Error loading bl Cache file: " + e.Message);
                    Plugin.Log.Debug(e);
                    return;
                }
            }
            try
            {
                List<TaohCache>? results = JsonConvert.DeserializeObject<List<TaohCache>>(
                    File.ReadAllText(HelpfulPaths.TAOHABLE_DATA)
                );

                if (results is null)
                {
                    Plugin.Log.Critical("There was an issue deserializing Taohable Data, it returned a null.");
                    return;
                }

                foreach (TaohCache result in results)
                {
                    bool ssRanked = result.ScoreSaberID is not null,
                        apRanked = result.ComplexityAccSaber is not null;

                    if (!ssRanked && !apRanked)
                        continue;

                    Map? apMap = null,
                        ssMap = null;
                    string songId = result.ScoreSaberID ?? result.BeatLeaderID ?? "";

                    if (apRanked)
                        apMap = new(result.Hash, Map.AP_MODE_NAME, result.Difficulty, songId, result);
                    if (ssRanked)
                        ssMap = new(result.Hash, Map.SS_MODE_NAME, result.Difficulty, songId, result);

                    Map map =
                        ssRanked && apRanked ? Map.Combine(apMap!, ssMap!)
                        : ssRanked ? ssMap!
                        : apMap!;

                    if (Data.ContainsKey(map.Hash))
                        Data[map.Hash].Combine(map);
                    else
                        Data[map.Hash] = map;
                }
                dataLoaded = true;
            }
            catch (Exception e)
            {
                Plugin.Log.Warn("Error loading Taohable Cache file: " + e.Message);
                Plugin.Log.Debug(e);
                if (!doNotLoop && e is JsonReaderException)
                {
                    File.Delete(HelpfulPaths.TAOHABLE_DATA); //In the case that there is an issue loading the file, try again.
                    LoadSomeTaohableData();
                    InitData(true, true);
                }
            }
        }

        private static void LoadSomeTaohableData()
        {
            if (PathUtils.EnsureTaohableDirectoryExists())
                return;

            Plugin.Log.Debug("Taoh data not up to date! Loading...");

            string filePath = HelpfulPaths.TAOHABLE_DATA;
            byte[]? data;

            (bool succeeded, HttpContent content) = APIHandler
                .CallAPI_Static(HelpfulPaths.TAOHABLE_API)
                .GetAwaiter()
                .GetResult();

            if (succeeded)
                data = content.ReadAsByteArrayAsync().GetAwaiter().GetResult();
            else
            {
                Plugin.Log.Warn("Could not fetch Taohable data.");
                return;
            }

            using FileStream fs = File.OpenWrite(filePath);
            fs.Write(data, 0, data.Length); //For some reason Stream.Write isn't implemented
        }

        private bool SetupMapData(CancellationToken ct)
        {
            ICacheModel data;
            string songId;
#if NEW_VERSION
            mode = SelectMode(beatmapDiff.beatmapCharacteristic.serializedName, Leaderboard);
            hash = beatmap.levelID.Split('_')[2].ToUpper(); // 1.37.0 and above
#else
            mode = SelectMode(beatmap.parentDifficultyBeatmapSet.beatmapCharacteristic.serializedName, Leaderboard);
            hash = beatmap.level.levelID.Split('_')[2].ToUpper(); // 1.34.2 and below
#endif
            try
            {
                Map? theMap = GetMap(hash, mode, Leaderboard, ct: ct).GetAwaiter().GetResult();
                if (theMap is null)
                {
                    Plugin.Log.Warn("The map is still not in the loaded cache.");
                    return false;
                }
#if NEW_VERSION
                Dictionary<string, MapDiffModel> hold = theMap.Get(beatmapDiff.difficulty); // 1.37.0 and above
#else
                Dictionary<string, MapDiffModel> hold = theMap.Get(beatmap.difficulty); // 1.34.2 and below
#endif
                if (!hold.TryGetValue(mode, out MapDiffModel holdInfo))
                {
                    Plugin.Log.Warn($"The mode '{mode}' doesn't exist.\nKeys: [{string.Join(", ", hold.Keys)}]");
                    return false;
                }
                data = holdInfo.Data;
                songId = holdInfo.SongId;
            }
            catch (Exception e)
            {
                Plugin.Log.Debug($"Data length: {Data.Count}");
                Plugin.Log.Warn("Hash: " + hash);
                Plugin.Log.Debug(e);
                return false;
            }
            Plugin.Log.Info("Map Hash: " + hash);
            return SetupMapData(data);
        }

        private bool SetupMapData(ICacheModel data)
        {
            if (!SetupMapData(data, Leaderboard, out float[]? ratings, mods))
                return false;
            this.ratings = RatingContainer.GetContainer(Leaderboard, ratings!);
            return true;
        }

        /// <summary>
        /// Given the difficulty <paramref name="data"/>, <paramref name="mods"/>, and <paramref name="leaderboard"/>,
        /// find what the star ratings are with as few API calls as possible.
        /// </summary>
        /// <param name="data">The difficulty data of the map.</param>
        /// <param name="leaderboard">The leaderboard in which the map is being checked on.</param>
        /// <param name="ratings">the ratings of the map. Outputs in the order of star, acc, pass, tech.</param>
        /// <param name="mods">What mods are used in the map (defaults to null for no mods).</param>
        /// <param name="quiet">Whether or not for this function to print out the ratings to read.</param>
        /// <returns>Whether or not the ratings were loaded successfully.</returns>
        public bool SetupMapData(
            ICacheModel data,
            Leaderboards leaderboard,
            out float[]? ratings,
            GameplayModifiers? mods = null,
            bool quiet = false
        )
        {
            if (
                data is null
                || data.ToString().Length <= 0
                || (data is BlCacheEntry && leaderboard != Leaderboards.Beatleader)
            )
            {
                ratings = null;
                return false;
            }
            switch (leaderboard)
            {
                case Leaderboards.Scoresaber:
                    ratings = new float[1];
                    ratings[0] = ((TaohCache)data).StarScoreSaber.GetValueOrDefault();
                    if (!quiet)
                        Plugin.Log.Info("Stars: " + ratings[0]);
                    return ratings[0] > 0;
                case Leaderboards.Accsaber:
                    ratings = new float[1];
                    ratings[0] = ((TaohCache)data).ComplexityAccSaber.GetValueOrDefault();
                    if (!quiet)
                        Plugin.Log.Info("Complexity: " + ratings[0]);
                    return ratings[0] > 0;
                case Leaderboards.Beatleader:
                    float multiplier = pathUtils.GetStarMultiplier(data, mods);
                    ratings = new float[4];
                    SongSpeed songSpeed = mods?.songSpeed ?? SongSpeed.Normal;
                    ratings[0] = pathUtils.GetRating(data, PPType.Star, Leaderboards.Beatleader, songSpeed);
                    ratings[1] = pathUtils.GetRating(data, PPType.Acc, Leaderboards.Beatleader, songSpeed) * multiplier;
                    ratings[2] =
                        pathUtils.GetRating(data, PPType.Pass, Leaderboards.Beatleader, songSpeed) * multiplier;
                    ratings[3] =
                        pathUtils.GetRating(data, PPType.Tech, Leaderboards.Beatleader, songSpeed) * multiplier;
                    string mod = HelpfulMisc.GetModifierShortname(songSpeed).ToUpper();
                    if (!quiet)
                        Plugin.Log.Info(
                            mod.Length > 0
                                ? $"{mod} Stars: {ratings[0]}\n{mod} Acc Rating: {ratings[1]}\n{mod} Pass Rating: {ratings[2]}\n{mod} Tech Rating: {ratings[3]}"
                                : $"Stars: {ratings[0]}\nAcc Rating: {ratings[1]}\nPass Rating: {ratings[2]}\nTech Rating: {ratings[3]}"
                        );
                    return ratings[3] > 0;
                default:
                    ratings = null;
                    return false;
            }
        }

        #endregion
        #region Updates
        internal static void UpdateText(
            bool displayFc,
            StringBuilder outpText,
            PPHandler ppVals,
            int mistakes,
            int displayRatingCount,
            PluginConfig pc
        )
        {
            string mistakeColor = $"<color={(mistakes == 0 ? "#999" : "red")}>";
            if (pc.SplitPPVals && displayRatingCount > 1)
            {
                for (int i = 0; i < 4; i++)
                    outpText.AppendLine(
                        DisplayFormatter(
                            displayFc,
                            pc.ExtraInfo && i == 3,
                            ppVals[0, i],
                            ppVals[1, i],
                            mistakeColor,
                            mistakes,
                            CurrentLabels![i]
                        )
                    );
            }
            else
                outpText.AppendLine(
                    DisplayFormatter(
                        displayFc,
                        pc.ExtraInfo,
                        ppVals[0, displayRatingCount - 1],
                        ppVals[1, displayRatingCount - 1],
                        mistakeColor,
                        mistakes,
                        CurrentLabels.Last()
                    )
                );
        }
        #endregion
    }
}
