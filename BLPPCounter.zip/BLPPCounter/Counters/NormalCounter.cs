using System.Threading;
using BLPPCounter.Settings.Configs;
using BLPPCounter.Utils.Containers;
using BLPPCounter.Utils.Enums;
using BLPPCounter.Utils.Map_Utils;
using TMPro;

namespace BLPPCounter.Counters
{
    public class NormalCounter(TMP_Text display, MapSelection map, CancellationToken ct) : MyCounters(display, map, ct)
    {
        public static string DisplayName => "Normal";
        public static string DisplayHandler => TheCounter.DisplayName;
        public static int OrderNumber => 0;
        public static Leaderboards ValidLeaderboards => Leaderboards.All;
        public override string Name => DisplayName;

        #region Init
        public override void SetupData(MapSelection map, CancellationToken ct)
        {
            ppHandler = new PPHandler(ratings, calc, pc.DecimalPrecision, 1) { UpdateFCEnabled = pc.PPFC };
            ppHandler.UpdateFC += (acc, extraVals, extraCalls, _) =>
                extraVals[1].SetValues(calc.GetPpWithSummedPp(acc, pc.DecimalPrecision, ratings));
        }

        public override void UpdateFormat() { }

        public static bool InitFormat() => TheCounter.FormatUsable;

        public static void ResetFormat() { }
        #endregion
        #region Updates
        public override void UpdateCounterInternal(
            float acc,
            int notes,
            int mistakes,
            float fcPercent,
            NoteData? currentNote
        )
        {
            ppHandler.Update(acc, mistakes, fcPercent);
            TheCounter.UpdateText(ppHandler.DisplayFC, outpText, ppHandler, mistakes, calc.DisplayRatingCount, pc);
        }

        public override void SoftUpdate(float acc, int notes, int mistakes, float fcPercent, NoteData? currentNote) { }
        #endregion
    }
}
