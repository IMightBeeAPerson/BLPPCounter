using System;
using System.Collections.Generic;
using System.Linq;
using BLPPCounter.Helpfuls;
using BLPPCounter.Settings.SettingHandlers;
using BS_Utils.Utilities;
using HarmonyLib;
using HMUI;
using JetBrains.Annotations;
using UnityEngine.SceneManagement;

namespace BLPPCounter.Patches
{
    [HarmonyPatch(typeof(SegmentedControl), "CreateCells")]
    public static class TabSelectionPatch
    {
#pragma warning disable IDE0051, IDE0044
        private static readonly HashSet<int> LoadedObjects = [];
        private static readonly Dictionary<string, Action> TabGotSelected = [];
        private static readonly HashSet<string> TabNames = [];
        public static event Action<string>? ModTabSelected;
        internal static Action? UpdateLastSegmentControl;
        public static string LastSelectedModTab { get; private set; } = "";
        private static string LastLoadedTabSelector = "";
        private static int ModTabHash = -1;
        private static bool ModTabFound => ModTabHash != -1;
        public static bool AllTabsFound => TabNames.Count == 0;
        public static bool IsOnModsTab;

        [UsedImplicitly]
        private static void Postfix(SegmentedControl __instance)
        {
            //Skip objects already loaded.
            if (LoadedObjects.Contains(__instance.GetHashCode()))
            {
                if (__instance.GetHashCode() == ModTabHash)
                    ModTabSelected?.Invoke("");
                return;
            }
            //string tabSelectorCells = __instance.cells.Aggregate("", (total, cell) => cell is TextSegmentedControlCell tscc ? total + ", " + tscc.text : total);
            //if (tabSelectorCells.Length > 2) tabSelectorCells = tabSelectorCells.Substring(2);
            //Plugin.Log.Info("Loaded, count = " + __instance.cells.Count() + ", names = [" + tabSelectorCells + "]");
            //Plugin.Log.Info($"Name: {__instance.name}");
#if NEW_VERSION
            if (
                !__instance.name.Equals("BSMLTabSelector")
                || PpInfoTabHandler.Instance.MainTabSelector.TextSegmentedControl.Equals(__instance)
            )
#else
            if (
                !__instance.name.Equals("BSMLTabSelector")
                || PpInfoTabHandler.Instance.MainTabSelector.textSegmentedControl.Equals(__instance)
            )
#endif
            {
                LoadedObjects.Add(__instance.GetHashCode());
                return;
            }
            string tabSelectorCells = __instance.cells.Aggregate(
                "",
                (total, cell) => cell is TextSegmentedControlCell tscc ? total + ", " + tscc.text : total
            )[2..];
            if (LastLoadedTabSelector.Equals(tabSelectorCells))
            {
                if (__instance.cells[0] is TextSegmentedControlCell tscc && !tscc.text.Equals(LastSelectedModTab))
                {
                    if (TabGotSelected.ContainsKey(tscc.text))
                        TabGotSelected[tscc.text]?.Invoke();
                    LastSelectedModTab = tscc.text;
                }
                return;
            }
            if (
                __instance.cells.Count == 2
                && __instance.cells.Any(scc => scc is TextSegmentedControlCell tscc && tscc.text.Equals("Mods"))
            )
            {
                ModTabSelected = str =>
                {
                    IsOnModsTab = str.Equals("Mods");
                    if (IsOnModsTab && LastSelectedModTab.Length != 0 && TabGotSelected.ContainsKey(LastSelectedModTab))
                        TabGotSelected[LastSelectedModTab]?.Invoke();
                };
                //Plugin.Log.Info("Event tab added");
                __instance.didSelectCellEvent += (sc, index) =>
                {
                    //Plugin.Log.Info("Cell selected!" + $" (Cell #{index})");
                    if (sc.cells[index] is TextSegmentedControlCell tscc)
                        ModTabSelected?.Invoke(tscc.text);
                };
                ModTabHash = __instance.GetHashCode();
                LoadedObjects.Add(ModTabHash);
                return;
            }
            LastLoadedTabSelector = tabSelectorCells;
            //Plugin.Log.Info($"AllTabsFound = {AllTabsFound}, Tabs left = {HelpfulMisc.Print(TabNames)}");
            //Plugin.Log.Info("Loaded, count = " + __instance.cells.Count() + ", names = [" + tabSelectorCells + "]");
            if (
                AllTabsFound
                && __instance.cells[0] is TextSegmentedControlCell textCell
                && TabGotSelected.ContainsKey(textCell.text)
            )
            {
                string s = textCell.text;
                TabGotSelected[s]?.Invoke();
                LastSelectedModTab = s;
                return;
            }
            IEnumerable<SegmentedControlCell> cells = __instance.cells.Where(scc =>
                scc is TextSegmentedControlCell tscc && TabNames.Contains(tscc.text)
            );
            if (!cells.Any())
                return;
            IEnumerable<string> names = cells.Select(scc => ((TextSegmentedControlCell)scc).text);
            foreach (string s in names)
            {
                TabNames.Remove(s);
                void CellEvent(SegmentedControl sc, int index)
                {
                    string currentName = s;
                    LastSelectedModTab = sc.cells[index] is TextSegmentedControlCell tscc ? tscc.text : "";
                    if (LastSelectedModTab.Equals(currentName))
                        TabGotSelected[currentName]?.Invoke();
                }
                __instance.didSelectCellEvent += CellEvent;
                CellEvent(__instance, 0);
                UpdateLastSegmentControl = () => CellEvent(__instance, 0); //this is stupid, but don't really feel like fixing it
            }
        }

        internal static void AddStartPatch()
        {
            SoloFlowPatch.EnteredMainMenu += () => ModTabSelected?.Invoke("");
        }

        public static void AddTabName(string name, Action TabSelected = null)
        {
            TabNames.Add(name);
            TabGotSelected.Add(name, TabSelected);
        }

        public static bool GetIfTabIsSelected(string tab) => tab?.Equals(LastSelectedModTab) ?? false;

        public static void AddToTabSelectedAction(string tab, Action toAdd)
        {
            if (!TabGotSelected.ContainsKey(tab))
                return;
            TabGotSelected[tab] += toAdd;
        }

        internal static void ClearData()
        {
            TabNames.Clear();
            foreach (string s in TabGotSelected.Keys)
                TabNames.Add(s);
        }
    }
}
