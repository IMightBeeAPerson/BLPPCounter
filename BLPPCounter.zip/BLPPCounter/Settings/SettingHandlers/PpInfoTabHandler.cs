using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using BeatSaberMarkupLanguage.Attributes;
using BeatSaberMarkupLanguage.Components;
using BeatSaberMarkupLanguage.Components.Settings;
using BeatSaberMarkupLanguage.Parser;
using BLPPCounter.CalculatorStuffs;
using BLPPCounter.Counters;
using BLPPCounter.Helpfuls;
using BLPPCounter.Helpfuls.FormatHelpers;
using BLPPCounter.Models;
using BLPPCounter.Models.Base;
using BLPPCounter.Models.MapModels;
using BLPPCounter.Patches;
using BLPPCounter.Settings.Configs;
using BLPPCounter.Settings.SettingHandlers.MenuSettingHandlers;
using BLPPCounter.Utils;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Enums;
using BLPPCounter.Utils.Map_Utils;
using BLPPCounter.Utils.Misc_Classes;
using BLPPCounter.Utils.Profile_Utils;
using BLPPCounter.Utils.Safety;
using BLPPCounter.Utils.TokenParser;
using BLPPCounter.Utils.TokenParser.Printers;
using BS_Utils.Utilities;
using HMUI;
using IPA.Utilities.Async;
using Newtonsoft.Json.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Zenject;
using static GameplayModifiers;

namespace BLPPCounter.Settings.SettingHandlers
{
    internal class PpInfoTabHandler : SafeNotifyPropertyChanged, IInitializable
    {
#pragma warning disable IDE0051, IDE0044, CS0649
        #region Misc Static Variables & Controllers
        [Inject]
        private readonly StandardLevelDetailViewController sldvc = null!;

        [Inject]
        private readonly GameplayModifiersPanelController gmpc = null!;

        [Inject]
        private readonly MainThreadDispatcher dispatcher = null!;

        [Inject]
        private readonly SettingsHandler settingsHandler = null!;

        [Inject]
        private readonly PluginConfig pc = null!;

        [Inject]
        private readonly LeaderboardSelector leaderboardSelector = null!;

        [Inject]
        private readonly PathUtils pathUtils = null!;

        public const string TabName = "PP Calculator";
        #endregion
        #region Variables
        private string CurrentMods = "",
            UnformattedCurrentMods = "",
            CurrentTab = "Info";
        private float CurrentModMultiplier = 1f;
#if NEW_VERSION
        private BeatmapKey CurrentMap; // 1.37.0 and above
#else
        private IDifficultyBeatmap CurrentMap; // 1.34.2 and below
#endif
        private (ICacheModel? Diffdata, JToken? Scoredata) CurrentDiff;
        private AsyncLock RefreshLock = new(),
            ProfileLock = new();
        private bool SelectButtonsOn = false;
        internal Leaderboards CurrentLeaderboard { get; private set; }
        private Calculator CurrentCalculator => leaderboardSelector.GetCalc(CurrentLeaderboard);
        private APIHandler CurrentAPI => leaderboardSelector.GetAPI(CurrentLeaderboard);
#if NEW_VERSION
        private readonly Dictionary<string, BeatmapKey> TabMapInfo = new() // 1.37.0 and above
#else
        private readonly Dictionary<string, IDifficultyBeatmap> TabMapInfo = new() // 1.34.2 and below
#endif
        {
            { "Info", default },
            { "Capture", default },
            { "Relative", default },
            { "Custom", default },
            { "Profile", default },
            { "Settings", default }, //This one is only here to provide a list of names
        };
        private readonly Dictionary<string, Action<PpInfoTabHandler>> Updates = new()
        {
            { "Info", new Action<PpInfoTabHandler>(pith => pith.UpdateInfo()) },
            { "Capture", new Action<PpInfoTabHandler>(pith => pith.UpdateCaptureValues()) },
            { "Relative", new Action<PpInfoTabHandler>(pith => pith.UpdateRelativeValues()) },
            { "Custom", new Action<PpInfoTabHandler>(pith => pith.UpdateCustomAccuracy()) },
            { "Profile", new Action<PpInfoTabHandler>(pith => pith.UpdateProfile()) },
        };
        private static readonly string[] SelectionButtonTags = ["SSButton", "NMButton", "FSButton", "SFButton"];
        private Table? ClanTableTable,
            RelativeTableTable,
            PPTableTable,
            PercentTableTable;
        public bool ChangeTabSettings = false;
        #region Relative Counter
        private static Func<string>? GetTarget,
            GetNoScoreTarget;
        private static FormatWrapper? NoScoreTargetWrapper;
        private float TargetPP = 0;
        private bool TargetHasScore = false;
        #endregion
        #region Clan Counter
        private float PPToCapture = 0;
        #endregion
        #region Custom Accuracy & Profile
        private bool IsPPMode = true;

        private Profile? CurrentProfile = null;
        private bool IsPlayTableOpen = false,
            UpdatePlayTableOnOpen = false;
        #endregion
        #endregion
        #region UI Variables & components
        [UIParams]
        private BSMLParserParams Parser = null!;
        private bool UsesMods => CurrentCalculator.UsesModifiers;
        private bool IsBL => CurrentLeaderboard == Leaderboards.Beatleader;
        private bool IsAP => CurrentLeaderboard == Leaderboards.Accsaber;
        private const bool ShowProfileTab = true;

        [UIComponent(nameof(MainTabSelector))]
        internal TabSelector MainTabSelector = null!;

        [UIComponent(nameof(SaveLeaderboardButton))]
        private Button SaveLeaderboardButton = null!;

        [UIComponent(nameof(CalcSelector))]
        internal ListSetting CalcSelector = null!;

#if DEBUG
        [UIValue(nameof(Testing))]
        private bool Testing => true;
#else
        [UIValue(nameof(Testing))]
        private bool Testing => false;
#endif

        [UIValue(nameof(ShowTrueID))]
        private bool ShowTrueID
        {
            get;
            set
            {
                field = value;
                MapID.gameObject.SetActive(!value);
                TrueMapID.gameObject.SetActive(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(CalcLeaderboard))]
        private string CalcLeaderboard
        {
            get => pc.CalcLeaderboard.ToString();
            set => pc.CalcLeaderboard = (Leaderboards)Enum.Parse(typeof(Leaderboards), value);
        }

        [UIValue(nameof(CalcLeaderboards))]
        private List<object> CalcLeaderboards =>
            [.. LeaderboardSettingsHandler.Instance.UsableLeaderboards.Select(a => a.ToString())];

        [UIAction(nameof(SaveLeaderboard))]
        private void SaveLeaderboard()
        {
            SaveLeaderboardButton.interactable = false;
            ChangeTabSettings = true;
            settingsHandler.CalcSelector.ReceiveValue();
            ResetTabs();
            Task.Run(async () =>
            {
                await Refresh(true);
                SaveLeaderboardButton.interactable = true;
            });
        }

        [UIValue(nameof(PercentSliderMin))]
        private float PercentSliderMin
        {
            get;
            set
            {
                field = value;
                CA_PercentSliderSlider.ChangeMinValue(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PercentSliderMax))]
        private float PercentSliderMax
        {
            get;
            set
            {
                field = value;
                CA_PercentSliderSlider.ChangeMaxValue(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PPSliderMin))]
        private int PPSliderMin
        {
            get;
            set
            {
                field = value;
                CA_PPSliderSlider.ChangeMinValue(value);
                ProfilePPSlider.ChangeMinValue(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PPSliderMax))]
        private int PPSliderMax
        {
            get;
            set
            {
                field = value;
                CA_PPSliderSlider.ChangeMaxValue(value);
                ProfilePPSlider.ChangeMaxValue(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(SliderIncrementNum))]
        private int SliderIncrementNum
        {
            get;
            set
            {
                field = value;
                UpdateTabSliders(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PercentSliderIncrementNum))]
        private float PercentSliderIncrementNum => SliderIncrementNum / 100f;

        [UIComponent(nameof(MinAccSlider))]
        private SliderSetting MinAccSlider = null!;

        [UIComponent(nameof(MaxAccSlider))]
        private SliderSetting MaxAccSlider = null!;

        [UIComponent(nameof(MinPPSlider))]
        private SliderSetting MinPPSlider = null!;

        [UIComponent(nameof(MaxPPSlider))]
        private SliderSetting MaxPPSlider = null!;

        [UIValue(nameof(ProfileTestPp))]
        private int ProfileTestPp
        {
            get => pc.ProfileTestPP;
            set => pc.ProfileTestPP = value;
        }

        [UIValue(nameof(APSetting))]
        private string APSetting
        {
            get => _APSetting.ToString();
            set
            {
                _APSetting = (APCategory)Enum.Parse(typeof(APCategory), value);
                Task.Run(() => UpdateProfile());
            }
        }

        [UIValue(nameof(APCategorySettings))]
        private List<object> APCategorySettings = [.. Enum.GetNames(typeof(APCategory)).Skip(1).Cast<object>()];
        private APCategory _APSetting = APCategory.All;

        [UIComponent(nameof(ProfileTab))]
        private Tab ProfileTab = null!;

        [UIComponent(nameof(PlayTable))]
        private TextMeshProUGUI PlayTable = null!;

        [UIComponent(nameof(PlayTableButtons))]
        private HorizontalLayoutGroup PlayTableButtons = null!;

        [UIObject(nameof(PlayTableModal))]
        private GameObject PlayTableModal = null!;

        [UIObject(nameof(SessionWindow))]
        private GameObject SessionWindow = null!;

        [UIComponent(nameof(SessionWindow_PlaysSet))]
        private TextMeshProUGUI SessionWindow_PlaysSet = null!;

        [UIComponent(nameof(SessionWindow_PpGained))]
        private TextMeshProUGUI SessionWindow_PpGained = null!;

        [UIComponent(nameof(SessionTable))]
        private CustomCellListTableData SessionTable = null!;

        [UIValue(nameof(SessionTable_Infos))]
        private List<object> SessionTable_Infos => CurrentProfile?.CurrentSession.Info ?? [];

        [UIComponent(nameof(PlusOneLabel))]
        private TextMeshProUGUI PlusOneLabel = null!;

        [UIComponent(nameof(PlusOneText))]
        private TextMeshProUGUI PlusOneText = null!;

        [UIComponent(nameof(ReloadDataButton))]
        private Button ReloadDataButton = null!;

        [UIComponent(nameof(AccSaberSetting))]
        private DropDownListSetting AccSaberSetting = null!;

        [UIComponent(nameof(ProfilePPSlider))]
        private SliderSetting ProfilePPSlider = null!;

        [UIComponent(nameof(WeightedText))]
        private TextMeshProUGUI WeightedText = null!;

        [UIComponent(nameof(WeightedTextValue))]
        private TextMeshProUGUI WeightedTextValue = null!;

        [UIComponent(nameof(ProfilePPText))]
        private TextMeshProUGUI ProfilePPText = null!;

        [UIComponent(nameof(ProfilePPTextValue))]
        private TextMeshProUGUI ProfilePPTextValue = null!;

        [UIValue(nameof(TestAcc))]
        private float TestAcc
        {
            get => pc.TestAccAmount;
            set => pc.TestAccAmount = value;
        }

        [UIValue(nameof(TestPp))]
        private int TestPp
        {
            get => pc.TestPPAmount;
            set => pc.TestPPAmount = value;
        }
#pragma warning disable CS0414
        [UIValue(nameof(TabPos))]
#if NEW_VERSION
        private float TabPos = -5.5f;
#else
        private float TabPos = 0f;
#endif
#pragma warning restore CS0414
        [UIComponent(nameof(PercentTable))]
        private TextMeshProUGUI PercentTable = null!;

        [UIComponent(nameof(PPTable))]
        private TextMeshProUGUI PPTable = null!;

        [UIComponent("ModeButton")]
        private TextMeshProUGUI ModeButtonText = null!;

        [UIObject(nameof(CA_PercentSlider))]
        private GameObject CA_PercentSlider = null!;

        [UIComponent(nameof(CA_PercentSlider))]
        private SliderSetting CA_PercentSliderSlider = null!;

        [UIObject(nameof(CA_PPSlider))]
        private GameObject CA_PPSlider = null!;

        [UIComponent(nameof(CA_PPSlider))]
        private SliderSetting CA_PPSliderSlider = null!;

        [UIObject(nameof(PercentTable_BG))]
        private GameObject PercentTable_BG = null!;

        [UIObject(nameof(PPTable_BG))]
        private GameObject PPTable_BG = null!;

        [UIComponent(nameof(RelativeText))]
        private TextMeshProUGUI RelativeText = null!;

        [UIComponent(nameof(RelativeTarget))]
        private TextMeshProUGUI RelativeTarget = null!;

        [UIComponent(nameof(RelativeTable))]
        private TextMeshProUGUI RelativeTable = null!;

        [UIComponent(nameof(CaptureTab))]
        private Tab CaptureTab = null!;

        [UIComponent(nameof(ClanTable))]
        private TextMeshProUGUI ClanTable = null!;

        [UIComponent(nameof(OwningClan))]
        private TextMeshProUGUI OwningClan = null!;

        [UIComponent(nameof(ClanTarget))]
        private TextMeshProUGUI ClanTarget = null!;

        [UIComponent(nameof(PPTarget))]
        private TextMeshProUGUI PPTarget = null!;

        [UIComponent(nameof(SpeedModText))]
        private TextMeshProUGUI SpeedModText = null!;

        [UIComponent(nameof(ModMultText))]
        private TextMeshProUGUI ModMultText = null!;

        [UIComponent(nameof(PrefixLabels))]
        private TextMeshProUGUI PrefixLabels = null!;

        [UIComponent(nameof(StarRatings))]
        private TextMeshProUGUI StarRatings = null!;

        [UIComponent(nameof(MapName))]
        private TextMeshProUGUI MapName = null!;

        [UIComponent(nameof(MapID))]
        private TextMeshProUGUI MapID = null!;

        [UIComponent(nameof(MapMode))]
        private TextMeshProUGUI MapMode = null!;

        [UIComponent(nameof(MapDiff))]
        private TextMeshProUGUI MapDiff = null!;

        [UIComponent(nameof(TrueMapID))]
        private TextMeshProUGUI TrueMapID = null!;

        [UIValue(nameof(BeatmapName))]
        private string BeatmapName
        {
            get => $"<color=#777>Map Name: <color=#AAA>{field.ClampString(25)}</color>";
            set
            {
                if (MapName is null)
                    return;

                field = value;
                MapName.text = $"<color=#777>Map Name: <color=#AAA>{value.ClampString(25)}</color>";
            }
        } = "";

        [UIValue(nameof(BeatmapID))]
        private string BeatmapID
        {
            get => $"<color=#777>Map ID: <color=#AAA>{field}</color>";
            set
            {
                if (MapID is null)
                    return;

                field = value;
                MapID.text = $"<color=#777>Map ID: <color=#AAA>{value}</color>";
            }
        } = "";

        [UIValue(nameof(MapModeText))]
        private string MapModeText
        {
            get => $"<color=#777>Map Type: <color=#AAA>{field}</color>";
            set
            {
                if (MapID is null)
                    return;

                field = value;
                MapMode.text = $"<color=#777>Map Type: <color=#AAA>{value}</color>";
            }
        } = "";

        [UIValue(nameof(MapDiffText))]
        private string MapDiffText
        {
            get => $"<color=#777>Map Difficulty: <color=#AAA>{field}</color>";
            set
            {
                if (MapID is null)
                    return;

                field = value;
                MapDiff.text = $"<color=#777>Map Difficulty: <color=#AAA>{value}</color>";
            }
        }

        [UIValue(nameof(TrueBeatmapID))]
        private string TrueBeatmapID
        {
            get => $"<color=#777>True Map ID: <color=#AAA>{field}</color>";
            set
            {
                if (MapID is null)
                    return;

                field = value;
                TrueMapID.text = $"<color=#777>True Map ID: <color=#AAA>{value}</color>";
            }
        }
        #endregion
        #region UI Functions
        [UIAction(nameof(Refresh))]
        private void ForceRefresh()
        {
            if (sldvc is not null && gmpc is not null)
                Refresh(true);
        }

        [UIAction(nameof(RefreshMods))]
        private void RefreshMods()
        {
            if (sldvc is not null && gmpc is not null)
            {
                UpdateMods();
                UpdateTabDisplay(true);
            }
        }

        [UIAction(nameof(ChangeTab))]
        private void ChangeTab(SegmentedControl sc, int index)
        {
            if (sc.cells[index] is TextSegmentedControlCell tscc)
            {
                if (CurrentTab.Equals("Settings"))
                    SaveSettings();
                CurrentTab = tscc.text;
                if (sldvc is not null && gmpc is not null)
                    UpdateTabDisplay();
            }
        }

        [UIAction(nameof(PercentFormat))]
        private string PercentFormat(float toFormat) => $"{toFormat:N2}%";

        [UIAction(nameof(PPFormat))]
        private string PPFormat(int toFormat) => $"{toFormat} " + GetPPLabel();

        [UIAction(nameof(ToggleCAMode))]
        private void ToggleCAMode()
        {
            IsPPMode = !IsPPMode;
            CA_PPSlider.SetActive(IsPPMode);
            CA_PercentSlider.SetActive(!IsPPMode);
            PPTable_BG.SetActive(!IsPPMode);
            PercentTable_BG.SetActive(IsPPMode);
            ModeButtonText.text = IsPPMode
                ? "<color=#A020F0>Input " + GetPPLabel().ToUpper()
                : "<color=#FFD700>Input Percentage";
            if (sldvc is not null)
            {
                UpdateCustomAccuracy();
                BuildTable();
            }
        }

        [UIAction(nameof(SelectSS))]
        private void SelectSS() => SelectMod(SongSpeed.Slower);

        [UIAction(nameof(SelectNM))]
        private void SelectNM() => SelectMod(SongSpeed.Normal);

        [UIAction(nameof(SelectFS))]
        private void SelectFS() => SelectMod(SongSpeed.Faster);

        [UIAction(nameof(SelectSF))]
        private void SelectSF() => SelectMod(SongSpeed.SuperFast);

        private void SelectMod(SongSpeed speed)
        {
            gmpc.ChangeSongSpeed(speed);
            UpdateMods();
            UpdateCurrentTable();
        }

        [UIAction(nameof(UpdateProfilePP))]
        private void UpdateProfilePP()
        {
            float ppAmount = Mathf.Round(ProfilePPSlider.Value);
            WeightedText.SetText($"<color=green>Weighted</color> {GetPPLabel()}");

            string weightedPp = $"{CurrentProfile?.GetWeightedPP(ppAmount) ?? -1}";
            if (weightedPp[0] == '-')
                weightedPp = "Unknown";
            WeightedTextValue.SetText("<color=#A72>" + weightedPp + "</color> " + GetPPLabel());

            ProfilePPText.SetText($"<color=yellow>Profile</color> {GetPPLabel()}");

            string profilePp = $"{CurrentProfile?.GetProfilePPRaw(ppAmount) ?? -1}";
            if (profilePp[0] == '-')
                profilePp = "Unknown";
            ProfilePPTextValue.SetText("<color=purple>" + profilePp + "</color> " + GetPPLabel());
        }

        [UIAction(nameof(DoTestThing))]
        private void DoTestThing()
        {
            //CurrentProfile.AddPlay(ProfilePPSlider.Value);
            UpdateProfilePP();
            UpdateProfile();
            const float acc = 0.999f;
#if NEW_VERSION
            CompletedMap(acc, sldvc.beatmapKey, sldvc.beatmapLevel);
#else
            CompletedMap(acc, sldvc.selectedDifficultyBeatmap);
#endif
        }

        [UIAction(nameof(RefreshProfilePP))]
        private void RefreshProfilePP() => Task.Run(RefreshProfileScores);

        private async Task RefreshProfileScores()
        {
            AsyncLock.Releaser? theLock = await ProfileLock.TryLockAsync();
            if (theLock is null)
                return;
            using (theLock.Value)
            {
                ReloadDataButton.interactable = false;

                if (CurrentProfile is null)
                    UpdateProfile();

                CurrentProfile?.ReloadScores();

                await Refresh(true);

                ReloadDataButton.interactable = true;
            }
        }

        private IEnumerator DelayUpdatePlayTable(Table theTable)
        {
            yield return new WaitForEndOfFrame();
            theTable.UpdateTable();
            const int ButtonWidths = 60; //correct value: 60
            PlayTableButtons.spacing = (theTable.TableWidth - ButtonWidths) / 2f;
            ((RectTransform)PlayTableModal.transform).sizeDelta = new Vector2(
                theTable.TableWidth,
                theTable.TableHeight * 1.5f
            );
            //theTable.SpawnButtonsForColumn(5, str => Plugin.Log.Info("Button Pressed! Id: " + str), PlayTableButton, "Buttons");
        }

        [UIAction(nameof(PlayTable_PageUp))]
        private void PlayTable_PageUp()
        {
            if (CurrentProfile is null || CurrentProfile.PlayTable is null)
                return;
            CurrentProfile.PageUp();
            dispatcher.EnqueueRoutine(DelayUpdatePlayTable(CurrentProfile.PlayTable));
        }

        [UIAction(nameof(PlayTable_PageTop))]
        private void PlayTable_PageTop()
        {
            if (CurrentProfile is null || CurrentProfile.PlayTable is null)
                return;
            CurrentProfile.PageTop();
            dispatcher.EnqueueRoutine(DelayUpdatePlayTable(CurrentProfile.PlayTable));
        }

        [UIAction(nameof(PlayTable_PageDown))]
        private void PlayTable_PageDown()
        {
            if (CurrentProfile is null || CurrentProfile.PlayTable is null)
                return;
            CurrentProfile.PageDown();
            dispatcher.EnqueueRoutine(DelayUpdatePlayTable(CurrentProfile.PlayTable));
        }

        [UIAction(nameof(SaveSettings))]
        private void SaveSettings()
        {
            pc.PercentSliderMin = PercentSliderMin;
            pc.PercentSliderMax = PercentSliderMax;
            pc.PPSliderMin = PPSliderMin;
            pc.PPSliderMax = PPSliderMax;
            pc.SliderIncrementNum = SliderIncrementNum;
            pc.ShowTrueID = ShowTrueID;
        }

        [UIAction("#ShowPlayTable")]
        private void ShowPlayTable()
        {
            IsPlayTableOpen = true;

            if (CurrentProfile is null)
                UpdateProfile();

            Table? theTable = CurrentProfile.PlayTable;

            if (theTable is null)
            {
                Profile.TextContainer = PlayTable;
                theTable = CurrentProfile.PlayTable;
            }

            if (!theTable.ContainerUpdated || UpdatePlayTableOnOpen)
            {
                UpdatePlayTableOnOpen = false;
                dispatcher.EnqueueRoutine(DelayUpdatePlayTable(theTable));
            }
        }

        [UIAction("#HidePlayTable")]
        private void HidePlayTable() => IsPlayTableOpen = false;

        [UIAction("#ShowSessionTable")]
        private void ShowSessionTable()
        {
            int hold = CurrentProfile?.CurrentSession.PlaysSet ?? 0;
            SessionWindow_PlaysSet.SetText(
                $"<color=#0F0>{hold}</color> Top {Profile.GetPlusOneCount(CurrentLeaderboard)} Score{(hold == 1 ? "" : "s")}"
            );
            SessionWindow_PpGained.SetText(
                $"+<color=purple>{CurrentProfile?.CurrentSession.GainedProfilePp ?? 0}</color> Profile {GetPPLabel().ToUpper()}"
            );

            IEnumerator WaitThenUpdate()
            {
                yield return new WaitForEndOfFrame();
#if NEW_VERSION
                SessionTable.Data = SessionTable_Infos;
                SessionTable.TableView.ReloadData();
#else
                SessionTable.data = SessionTable_Infos;
                SessionTable.tableView.ReloadData();
#endif
                ((RectTransform)SessionWindow.transform).sizeDelta = new Vector2(120, 50);
            }
            dispatcher.EnqueueRoutine(WaitThenUpdate());
        }

        [UIAction("#UpdateCurrentTable")]
        private void UpdateCurrentTable() => BuildTable();

        [UIAction("#UpdateCurrentTab")]
        private void UpdateCurrentTab() => UpdateTabDisplay(true);

        [UIAction("#post-parse")]
        private void DoStuff()
        {
            HelpfulMisc.CoupleMinMaxSliders(MinAccSlider, MaxAccSlider);
            HelpfulMisc.CoupleMinMaxSliders(MinPPSlider, MaxPPSlider);
            foreach (string s in SelectionButtonTags)
                foreach (GameObject go in Parser.GetObjectsWithTag(s))
                    go.SetActive(false);
            CaptureTab.IsVisible = IsBL;
            ProfileTab.IsVisible = ShowProfileTab;
            AccSaberSetting.gameObject.SetActive(IsAP);
            MapID.gameObject.SetActive(!ShowTrueID);
            TrueMapID.gameObject.SetActive(ShowTrueID);
        }
        #endregion
        #region Inits
        internal void SldvcInit()
        {
            sldvc.didChangeContentEvent += async (a, b) => await Refresh().ConfigureAwait(false);
#if NEW_VERSION
            sldvc.didChangeDifficultyBeatmapEvent += async a => await Refresh().ConfigureAwait(false); // 1.37.0 and above
#else
            sldvc.didChangeDifficultyBeatmapEvent += async (a, b) => await Refresh().ConfigureAwait(false); // 1.34.2 and below
#endif
        }
        //internal void gmpcInit() { gmpc.didChangeGameplayModifiersEvent += UpdateMods; UpdateMods(); }

        #endregion
        #region Formatting
        #region Relative Counter
        [MemberNotNull(nameof(NoScoreTargetWrapper), nameof(GetNoScoreTarget), nameof(GetTarget))]
        private static void InitFormatters(PluginConfig pc)
        {
            if (NoScoreTargetWrapper is not null && GetNoScoreTarget is not null && GetTarget is not null)
                return;

            NoScoreTargetWrapper = new FormatWrapper((typeof(string), 't'));
            Formatter f = new(
                TokenParser.ParseTokens(
                    pc.MessageSettings.TargetHasNoScoreMessage,
                    new Dictionary<string, char>() { { "Target", 't' } }
                ),
                NoScoreTargetWrapper
            );
            f.PromiseValueForTokens();
            Printer simple = f.GetOutput();
            GetNoScoreTarget = () =>
            {
                NoScoreTargetWrapper.SetValue('t', Targeter.TargetName, typeof(string));
                return simple.Print();
            };
            GetTarget = () =>
                TheCounter.TargetFormatter(Targeter.TargetName.ClampString(pc.MaxNameLength), "")
                ?? "Target formatter is null";
        }

        private float GetAccToBeatTarget()
        {
            if (
                CurrentDiff.Diffdata is null
                || CurrentDiff.Scoredata is null
                || CurrentAPI.AreRatingsNull(CurrentDiff.Diffdata)
            )
                return 0f;
            return CurrentCalculator.GetAcc(
                CurrentAPI.GetPP(CurrentDiff.Scoredata),
                pc.DecimalPrecision,
                CurrentAPI.GetRatings(CurrentDiff.Diffdata)
            );
        }

        private async Task<float> UpdateTargetPP()
        {
            if (sldvc is null)
                return 0f;
#if NEW_VERSION
            CurrentMap = sldvc.beatmapKey; // 1.37.0 and above
            if (CurrentMap == default)
                return 0f;
#else
            CurrentMap = sldvc.selectedDifficultyBeatmap; // 1.34.2 and below
            if (CurrentMap is null)
                return 0f;
#endif
            CurrentDiff = (null, null);
            if (!sldvc.beatmapLevel.levelID[..6].Equals("custom"))
                return 0.0f; //means the level selected is not custom
#if NEW_VERSION
            string? mode = CurrentMap.beatmapCharacteristic.serializedName; // 1.37.0 and above
#else
            string? mode = CurrentMap.parentDifficultyBeatmapSet.beatmapCharacteristic.serializedName; // 1.34.2 and below
#endif
            string hash = sldvc.beatmapLevel.levelID.Split('_')[2];
            JObject? scoreData =
                await CurrentAPI
                    .GetScoreData(
                        Targeter.TargetID,
                        hash,
                        CurrentMap.difficulty.ToString().Replace("+", "Plus"),
                        mode,
                        true //Debug option, just prevents prints when the API was called.
                    )
                    .ConfigureAwait(false) as JObject;

            TargetHasScore = scoreData is not null;
            if (!TargetHasScore)
            {
                await UpdateDiff().ConfigureAwait(false);
                return 0.0f;
            } //target doesn't have a score on this diff.

            ICacheModel? diffData = null;
            try
            {
                string actualMode = TheCounter.SelectMode(mode, CurrentLeaderboard);

                Map? map = await TheCounter.GetMap(hash, actualMode, CurrentLeaderboard, true);
                //Plugin.Log.Info($"SelectedMap: {map}");
                if (map is null || !map.TryGet(actualMode, CurrentMap.difficulty, out MapDiffModel? val))
                    throw new Exception();

                BeatmapID = val.SongId;
                diffData = val.Data;

                if (IsAP)
                {
                    float complexity = diffData is TaohCache taohCache ? taohCache.ComplexityAccSaber ?? -1f : -1f;

                    if (Mathf.Approximately(complexity, -1f))
                    {
                        Plugin.Log.Critical("Cannot get the complexity!!");
                        throw new Exception();
                    }

                    scoreData!.Property("accuracy")?.AddAfterSelf(new JProperty("complexity", complexity));
                }

                if (IsBL)
                    TrueBeatmapID = BLAPI.CleanUpId(BeatmapID);
                else if (map.Get(mode ?? "Standard", CurrentMap.difficulty) is not null and MapDiffModel mapDiff)
                    TrueBeatmapID = BLAPI.CleanUpId(mapDiff.SongId);

#if NEW_VERSION
                BeatmapName = sldvc.beatmapLevel.songName;
#else
                BeatmapName = CurrentMap.level.songName;
#endif
            }
            catch (Exception)
            { //This exception should only happen when a map isn't on the radar of the selected leaderboard (aka unranked), and thus doesn't need to be broadcasted.
                await UpdateDiff(true).ConfigureAwait(false);
                return 0.0f;
            }
            try
            {
                MapDiffText = HelpfulMisc.AddSpaces(CurrentMap.difficulty.ToString().Replace("+", "Plus"));

                if (mode is not null)
                    MapModeText = HelpfulMisc.AddSpaces(mode);

                float outp = CurrentAPI.GetPP(scoreData!);
                if (outp == 0.0f && !CurrentAPI.AreRatingsNull(diffData)) //If the score set doesn't have a pp value, calculate one manually. Make sure there are ratings to do calculation, otherwise skip.
                    outp = CurrentCalculator.Inflate(
                        CurrentCalculator.GetSummedPp(
                            CurrentAPI.GetScore(scoreData!) / (float)CurrentAPI.GetMaxScore(diffData),
                            CurrentAPI.GetRatings(diffData)
                        )
                    );
                CurrentDiff = (diffData, scoreData);
                if (UnformattedCurrentMods.Length > 0)
                    CurrentModMultiplier = pathUtils.GetMultiAmounts(diffData, UnformattedCurrentMods.Split(' '));
                return outp;
            }
            catch (Exception e)
            {
                Plugin.Log.Error($"Error while updating target PP: {e}");
                TargetHasScore = false;
                await UpdateDiff(true).ConfigureAwait(false);
            }
            return 0.0f;
        }
        #endregion
        private bool BuildTable(
            Func<float[], string> valueCalc,
            TextMeshProUGUI table,
            [NotNullWhen(true)] ref Table? tableTable,
            string suffix = "%",
            string speedLbl = "<color=blue>Speed</color>",
            string accLbl = "<color=#0D0>Acc</color> to Cap",
            string gnLbl = "With <color=green>Selected Mods</color>"
        )
        {
            Calculator calc = CurrentCalculator;
            string[][] arr = new string[]
            {
                "<color=red>Slower</color>",
                "<color=#aaa>Normal</color>",
                "<color=#0F0>Faster</color>",
                "<color=#FFD700>Super Fast</color>",
            }.RowToColumn(3);
            //ss-sf, [star, acc, pass, tech] (selects by leaderboard)

            if (CurrentDiff.Diffdata is null)
                return false;

            float[] ratings = UsesMods
                ?
                [
                    .. pathUtils
                        .GetAllRatings(CurrentDiff.Diffdata, calc)
                        .SelectMany(rating => rating.GetRatings(calc.Leaderboard))
                        .Where(num => num > 0f),
                ]
                : [pathUtils.GetRating(CurrentDiff.Diffdata, PPType.Star, calc.Leaderboard)];
            if (!UsesMods)
            {
                float[] newArr = new float[ratings.Length * 4];
                for (int i = 0; i < ratings.Length; i++)
                {
                    newArr[i] = ratings[i];
                    newArr[i + ratings.Length] = ratings[i];
                    newArr[i + ratings.Length * 2] = ratings[i];
                    newArr[i + ratings.Length * 3] = ratings[i];
                }
                ratings = newArr;
            }
            int len = ratings.Length / 4; //divide by 4 because 3 speed mods + 1 no mod
            /*Plugin.Log.Info($"rating len: {ratings.Length}, len: {len}");
            if (ratings.Length == 0 || len == 0)
            {
                tableTable = null;
                Plugin.Log.Info(data.ToString());
                return;
            }//*/
            for (int i = 0; i < arr.Length; i++)
                arr[i][1] =
                    "<color=#0c0>" + valueCalc.Invoke([.. ratings.Skip(i * len).Take(len)]) + "</color>" + suffix;

            if (!Mathf.Approximately(CurrentModMultiplier, 1.0f))
                for (int i = 0; i < arr.Length; i++)
                    arr[i][2] =
                        "<color=green>"
                        + valueCalc([
                            .. ratings.Skip(i * len).Take(len).Select(current => current * CurrentModMultiplier),
                        ])
                        + "</color>"
                        + suffix;
            else
                for (int i = 0; i < arr.Length; i++)
                    arr[i][2] = "N/A";

            if (tableTable is null)
                tableTable = new Table(table, arr, speedLbl, accLbl, gnLbl) { HasEndColumn = true };
            else
                tableTable.SetValues(arr);
            Table tableTableTable = tableTable; //this is done because ref vars are not allowed to be passed into functions (probably something to do with security being compromised).
            IEnumerator DelayRoutine()
            {
                yield return new WaitForEndOfFrame();
                tableTableTable.UpdateTable();
                TurnOnSelectButtons();
            }
            ;
            dispatcher.EnqueueRoutine(DelayRoutine());

            return true;
        }

        private void BuildTable()
        {
            switch (CurrentTab)
            {
                case "Capture":
                    if (!IsBL)
                        break;
                    if (
                        BuildTable(
                            ratings => CurrentCalculator.GetAcc(PPToCapture, pc.DecimalPrecision, ratings) + "",
                            ClanTable,
                            ref ClanTableTable
                        )
                    )
                        ClanTableTable.HighlightCell(
                            HelpfulMisc.OrderSongSpeedCorrectly(gmpc.gameplayModifiers.songSpeed) + 1,
                            0
                        );
                    break;
                case "Relative":
                    if (
                        BuildTable(
                            ratings => CurrentCalculator.GetAcc(TargetPP, pc.DecimalPrecision, ratings) + "",
                            RelativeTable,
                            ref RelativeTableTable,
                            accLbl: "<color=#0D0>Acc</color> to Beat"
                        )
                    )
                        RelativeTableTable.HighlightCell(
                            HelpfulMisc.OrderSongSpeedCorrectly(gmpc.gameplayModifiers.songSpeed) + 1,
                            0
                        );
                    break;
                case "Custom":
                    if (IsPPMode)
                    {
                        if (
                            BuildTable(
                                ratings => CurrentCalculator.GetAcc(TestPp, pc.DecimalPrecision, ratings) + "",
                                PercentTable,
                                ref PercentTableTable,
                                accLbl: "<color=#0D0>Acc</color>"
                            )
                        )
                            PercentTableTable.HighlightCell(
                                HelpfulMisc.OrderSongSpeedCorrectly(gmpc.gameplayModifiers.songSpeed) + 1,
                                0
                            );
                    }
                    else
                    {
                        if (
                            BuildTable(
                                ratings =>
                                    CurrentCalculator.GetSummedPp(TestAcc / 100.0f, pc.DecimalPrecision, ratings) + "",
                                PPTable,
                                ref PPTableTable,
                                $" {GetPPLabel()}",
                                accLbl: $"<color=#0D0>{GetPPLabel().ToUpper()}</color>"
                            )
                        )
                            PPTableTable.HighlightCell(
                                HelpfulMisc.OrderSongSpeedCorrectly(gmpc.gameplayModifiers.songSpeed) + 1,
                                0
                            );
                    }
                    break;
                default:
                    return;
            }
        }

        private static string Grammarize(string mods) //this is very needed :)
        {
            int commaCount = mods.Count(c => c == ',');
            if (commaCount == 0)
                return mods;
            if (commaCount == 1)
                return mods.Replace(", ", " and ");
            return mods[..mods.LastIndexOf(',')] + " and" + mods[(mods.LastIndexOf(',') + 1)..];
        }

        private void UpdateMods() //this is why you use bitmasks instead of a billion bools vars
        {
            string newMods = "";
            UnformattedCurrentMods = "";
            GameplayModifiers mods = gmpc.gameplayModifiers;

            switch (mods.songSpeed)
            { //Speed mods are not added to UnformattedCurrentMods because they are handled in a different way.
                case SongSpeed.Slower:
                    newMods += "Slower Song, ";
                    break;
                case SongSpeed.Faster:
                    newMods += "Faster Song, ";
                    break;
                case SongSpeed.SuperFast:
                    newMods += "Super Fast Song, ";
                    break;
            }

            if (mods.ghostNotes)
            {
                UnformattedCurrentMods += "gn ";
                newMods += "Ghost Notes, ";
            }
            if (mods.disappearingArrows)
            {
                UnformattedCurrentMods += "da ";
                newMods += "Disappearing Arrows, ";
            }
            if (mods.energyType == EnergyType.Battery)
                newMods += "Four Lifes, ";
            if (mods.noArrows)
            {
                UnformattedCurrentMods += "na ";
                newMods += "No Arrows, ";
            }
            if (mods.noFailOn0Energy)
                newMods += "No Fail, ";
            if (mods.zenMode)
                newMods += "Zen Mode (why are you using zen mode), ";
            if (mods.instaFail)
                newMods += "One Life, ";
            if (mods.noBombs)
            {
                UnformattedCurrentMods += "nb ";
                newMods += "No Bombs, ";
            }
            if (mods.proMode)
            {
                UnformattedCurrentMods += "pm ";
                newMods += "Pro Mode, ";
            }
            if (mods.smallCubes)
            {
                UnformattedCurrentMods += "sc ";
                newMods += "Small Cubes, ";
            }
            if (mods.strictAngles)
            {
                UnformattedCurrentMods += "sa ";
                newMods += "Strict Angles, ";
            }
            if (mods.enabledObstacleType == EnabledObstacleType.NoObstacles)
            {
                UnformattedCurrentMods += "no ";
                newMods += "No Walls, ";
            }

            CurrentMods = newMods.Length > 1 ? Grammarize(newMods[..^2]) : "";

            if (UnformattedCurrentMods.Length > 0)
                UnformattedCurrentMods = UnformattedCurrentMods.Trim();
            if (!UsesMods)
                return;

            float modMult = CurrentModMultiplier;
            if (CurrentDiff.Diffdata is not null)
                CurrentModMultiplier = pathUtils.GetMultiAmounts(
                    CurrentDiff.Diffdata,
                    UnformattedCurrentMods.Split(' ')
                );

            if (!Mathf.Approximately(modMult, CurrentModMultiplier))
            {
                TabMapInfo["Capture"] = default;
                TabMapInfo["Relative"] = default;
            }
        }

        private void TurnOnSelectButtons()
        {
            if (SelectButtonsOn)
                return;
            foreach (string s in SelectionButtonTags)
                foreach (GameObject go in Parser.GetObjectsWithTag(s))
                    go.SetActive(true);
            SelectButtonsOn = true;
        }
        #endregion
        #region Misc Functions
        private void ChangeMapListeners(bool toEnable)
        {
            if (toEnable)
            {
                BSEvents.levelCleared += SucceededMap;
                /*BSEvents.levelFailed += FailedMap;
                BSEvents.levelQuit += FailedMap;
                BSEvents.levelRestarted += FailedMap;*/
            }
            else
            {
                BSEvents.levelCleared -= SucceededMap;
                /*BSEvents.levelFailed -= FailedMap;
                BSEvents.levelQuit -= FailedMap;
                BSEvents.levelRestarted -= FailedMap;*/
            }
        }

        private void SucceededMap(StandardLevelScenesTransitionSetupDataSO transition, LevelCompletionResults results)
        {
            ClearMapTabs();
            TheCounter.ClearCounter();
            Task.Run(async () =>
            {
#if NEW_VERSION
                await CompletedMap(
                    HelpfulMisc.GetAcc(transition, results),
                    transition.beatmapKey,
                    transition.beatmapLevel
                );
#else
                await CompletedMap(HelpfulMisc.GetAcc(transition, results), transition.difficultyBeatmap);
#endif
            });
        }
        /*private void FailedMap(StandardLevelScenesTransitionSetupDataSO transition, LevelCompletionResults results)
        {
            FinalMapData = default;
        }*/
#if NEW_VERSION
        private Task CompletedMap(float finalAcc, BeatmapKey diffData, BeatmapLevel levelData)
        {
            return CompletedMap(
                finalAcc,
                levelData.levelID.Split('_')[2],
                levelData.songName,
                diffData.difficulty,
                diffData.beatmapCharacteristic.serializedName
            );
        }
#else
        private Task CompletedMap(float finalAcc, IDifficultyBeatmap data)
        {
            return CompletedMap(
                finalAcc,
                data.level.levelID.Split('_')[2],
                data.level.songName,
                data.difficulty,
                data.parentDifficultyBeatmapSet.beatmapCharacteristic.serializedName
            );
        }
#endif

        private Task CompletedMap(float finalAcc, string hash, string mapName, BeatmapDifficulty diff, string mode)
        {
            //finalAcc = 1.0f;
            Plugin.Log.Debug(
                "Map completion info: " + HelpfulMisc.Print(new object[5] { finalAcc, hash, mapName, diff, mode })
            );
            if (float.IsNaN(finalAcc))
            {
                TheCounter.LastMap = default;
                return Task.CompletedTask;
            }
            Task outp = Task.Run(async () =>
            {
                if (await Profile.AddPlay(Targeter.PlayerID, hash, finalAcc, mapName, diff, mode).ConfigureAwait(false))
                {
                    await Refresh(true).ConfigureAwait(false);
                }
            });
            TheCounter.LastMap = default;
            return outp ?? Task.CompletedTask;
        }

        private void UpdateDisplayVisibility(bool waitForEndOfFrame = true)
        {
            void Update()
            {
                AccSaberSetting.gameObject.SetActive(IsAP);
                if ((CaptureTab.IsVisible == IsBL) && (ProfileTab.IsVisible == ShowProfileTab))
                    return;
#if NEW_VERSION
                int currentTabNum = MainTabSelector.TextSegmentedControl.selectedCellNumber;
#else
                int currentTabNum = MainTabSelector.textSegmentedControl.selectedCellNumber;
#endif

                bool change = CaptureTab.IsVisible != IsBL;
                bool keepPos = !change || !CurrentTab.Equals(CaptureTab.TabName);
                if (change)
                {
                    CaptureTab.IsVisible = IsBL;
                    if (currentTabNum >= TabMapInfo.Keys.ToList().IndexOf(CaptureTab.TabName))
                        currentTabNum += IsBL ? 1 : -1;
                }

                change = ProfileTab.IsVisible != ShowProfileTab;
                keepPos &= !change || !CurrentTab.Equals(ProfileTab.TabName);
                if (change)
                {
                    ProfileTab.IsVisible = ShowProfileTab;
                    if (currentTabNum >= TabMapInfo.Keys.ToList().IndexOf(ProfileTab.TabName))
                        currentTabNum += ShowProfileTab ? 1 : -1;
                }

                MainTabSelector.ForceSelectAndNotify(keepPos ? currentTabNum : 0);
                if (!keepPos)
                    CurrentTab = TabMapInfo.Keys.First();
            }
            IEnumerator WaitThenUpdate()
            {
                yield return new WaitForEndOfFrame();
                Update();
            }
            if (waitForEndOfFrame)
                dispatcher.EnqueueRoutine(WaitThenUpdate());
            else
                Update();
        }

        public string GetPPLabel() => IsAP ? "ap" : "pp";

        public Task UpdateTabDisplay(bool forceUpdate = false, bool runAsync = true)
        {
            if (CurrentTab.Length == 0 || (!forceUpdate && TabMapInfo[CurrentTab] == CurrentMap))
                return Task.CompletedTask;

            async Task Update()
            {
                if (ChangeTabSettings)
                {
                    ChangeTabSettings = false;
                    await UnityMainThreadTaskScheduler.Factory.StartNew(() => UpdateDisplayVisibility(false));
                }
                //Plugin.Log.Info("DiffData:\n" + CurrentDiff.Diffdata);
                if (CurrentTab.Equals("Settings"))
                    return;
                TabMapInfo[CurrentTab] = CurrentMap;
                Updates[CurrentTab].Invoke(this);
                BuildTable();
            }
            if (runAsync)
                return UnityMainThreadTaskScheduler.Factory.StartNew(Update);
            return Update();
        }

        private void UpdateInfo()
        {
            const string Delimiter = "\n";
            const string LineHeight = "80";
            PrefixLabels.SetText(
                $"<line-height={LineHeight}%>"
                    + CurrentCalculator.StarLabels.Aggregate((total, current) => total + Delimiter + current)
            );
            if (CurrentDiff.Diffdata is not null && CurrentAPI.MapIsUsable(CurrentDiff.Diffdata))
            {
                const char Star = (char)9733;
                switch (CurrentLeaderboard)
                {
                    case Leaderboards.Beatleader:
                        (float accRating, float passRating, float techRating, float starRating) =
                            HelpfulMisc.GetRatingsAndStar(
                                CurrentDiff.Diffdata,
                                gmpc.gameplayModifiers.songSpeed,
                                CurrentModMultiplier
                            );
                        StarRatings.SetText(
                            $"<line-height={LineHeight}%>"
                                + Math.Round(accRating, pc.DecimalPrecision)
                                + ' '
                                + Star
                                + Delimiter
                                + Math.Round(passRating, pc.DecimalPrecision)
                                + ' '
                                + Star
                                + Delimiter
                                + Math.Round(techRating, pc.DecimalPrecision)
                                + ' '
                                + Star
                                + Delimiter
                                + Math.Round(starRating, pc.DecimalPrecision)
                                + ' '
                                + Star
                        );
                        break;
                    case Leaderboards.Scoresaber:
                        StarRatings.SetText(
                            $"<line-height={LineHeight}%>{Math.Round(CurrentAPI.GetRatings(CurrentDiff.Diffdata)[0], pc.DecimalPrecision)} {Star}"
                        );
                        break;
                    case Leaderboards.Accsaber:
                        StarRatings.SetText(
                            $"<line-height={LineHeight}%>{Math.Round(CurrentAPI.GetRatings(CurrentDiff.Diffdata)[0], pc.DecimalPrecision)} {Star}"
                        );
                        break;
                }
            }
            else
            {
                const string failText = "Not Found!";
                string failString = "";
                for (int i = 0; i < CurrentCalculator.DisplayRatingCount; i++)
                    failString += Delimiter + failText;
                StarRatings.SetText($"<line-height={LineHeight}%>" + failString[Delimiter.Length..]);
            }
            SpeedModText.SetText("<color=green>" + HelpfulMisc.AddSpaces(gmpc.gameplayModifiers.songSpeed.ToString()));
            ModMultText.SetText($"x{Math.Round(CurrentModMultiplier, 2):N2}");
        }

        private void UpdateCaptureValues()
        {
            if (
                !IsBL
                || CurrentDiff.Diffdata is null
                || !leaderboardSelector.GetAPI(CurrentLeaderboard).MapIsUsable(CurrentDiff.Diffdata)
            )
                return;
            ClanTarget.SetText(TargetHasScore ? GetTarget?.Invoke() : GetNoScoreTarget?.Invoke());
            PPToCapture = ClanCounter.LoadNeededPp(BeatmapID, out _, out string owningClan)?.First() ?? -1f;
            OwningClan.SetText($"<color=red>{owningClan}</color> owns this map.");
            PPTarget.SetText($"<color=#0F0>{Math.Round(PPToCapture, pc.DecimalPrecision)}</color> " + GetPPLabel());
        }

        private void UpdateRelativeValues()
        {
            RelativeText.SetText(TargetHasScore ? GetTarget?.Invoke() : GetNoScoreTarget?.Invoke());
            RelativeTarget.SetText($"<color=#0F0>{Math.Round(TargetPP, pc.DecimalPrecision)}</color> " + GetPPLabel());
        }

        private void UpdateCustomAccuracy()
        {
            if (CurrentDiff.Diffdata is null)
                return;

            if (IsPPMode)
                pc.TestAccAmount = TestAcc;
            else
                pc.TestPPAmount = TestPp;
        }

        private async Task UpdateDiff(bool mapFailed = false)
        {
            try
            {
#if NEW_VERSION
                BeatmapDifficulty diff = sldvc.beatmapKey.difficulty; // 1.37.0 and below
                string? modeName = sldvc.beatmapKey.beatmapCharacteristic.serializedName;
                string hash = sldvc.beatmapLevel.levelID.Split('_')[2];
#else
                BeatmapDifficulty diff = sldvc.selectedDifficultyBeatmap.difficulty; // 1.34.2 and above
                string? modeName = sldvc
                    .selectedDifficultyBeatmap
                    .parentDifficultyBeatmapSet
                    .beatmapCharacteristic
                    .serializedName;
                string hash = sldvc.selectedDifficultyBeatmap.level.levelID.Split('_')[2];
#endif
                string actualModeName = TheCounter.SelectMode(modeName, CurrentLeaderboard);
                Map? map = mapFailed ? null : await TheCounter.GetMap(hash, actualModeName, CurrentLeaderboard, true);
                MapDiffModel? val = null;

                modeName ??= "Standard";

                bool failed = !(map?.TryGet(actualModeName, diff, out val) ?? false);
                if (failed)
                {
                    //Plugin.Log.Warn("Map failed to load. Most likely unranked.");
                    map = await TheCounter.GetMap(hash, modeName, Leaderboards.Beatleader, true);
                    if (map is null || !map.TryGet(modeName, diff, out val))
                    {
                        Plugin.Log.Error(
                            "Completely failed to load any map whatsoever. Either you are disconnected from the internet or beatleader is down."
                        );
                        return;
                    }
                }
                BeatmapID = val!.SongId;
                ICacheModel tokens = val!.Data;

                if (IsBL || failed)
                    TrueBeatmapID = BLAPI.CleanUpId(BeatmapID);
                else
                {
                    map = await TheCounter.GetMap(hash, modeName, Leaderboards.Beatleader, true);
                    if (
                        map is not null
                        && map.Get(modeName, CurrentMap.difficulty) is not null and MapDiffModel mapDiff
                    )
                        TrueBeatmapID = BLAPI.CleanUpId(mapDiff.SongId);
                }
                //Plugin.Log.Info("CurrentMap\n" + map);
                CurrentDiff = (tokens, CurrentDiff.Scoredata);
                MapDiffText = HelpfulMisc.AddSpaces(CurrentMap.difficulty.ToString().Replace("+", "Plus"));
                MapModeText = HelpfulMisc.AddSpaces(modeName);
#if NEW_VERSION
                BeatmapName = sldvc.beatmapLevel.songName;
#else
                BeatmapName = CurrentMap.level.songName;
#endif
                if (failed || CurrentAPI.AreRatingsNull(CurrentDiff.Diffdata))
                    CurrentDiff = (null, null);
            }
            catch (Exception e)
            {
                Plugin.Log.Error(
                    "Error updating diff data. This likely means the map isn't ranked on the selected leaderboard, or there was an issue with the API. \nException message: "
                        + e.Message
                );
                Plugin.Log.Debug("Stack trace: " + e.StackTrace);
                CurrentDiff = (null, null);
            }
        }

        [MemberNotNull(nameof(CurrentProfile))]
        private void UpdateProfile()
        {
            CurrentProfile = IsAP
                ? Profile.GetProfile(CurrentLeaderboard, Targeter.PlayerID, _APSetting)
                : Profile.GetProfile(CurrentLeaderboard, Targeter.PlayerID);
            CurrentProfile.ReloadTableValues();
            PlusOneLabel.SetText("+1 " + GetPPLabel());
            PlusOneText.SetText($"<color=#0F0>{CurrentProfile.PlusOne}</color> {GetPPLabel()}");
            UpdateProfilePP();
        }

        public Task Refresh(bool forceRefresh = false) => DoRefresh(forceRefresh);

        private async Task DoRefresh(bool forceRefresh)
        {
            //Plugin.Log.Info($"ActualMap: {sldvc?.selectedDifficultyBeatmap.level.songName ?? "null"} || Currently Saved Map: {CurrentMap?.level.songName ?? "null"}");
            //Plugin.Log.Info($"ActualMap: [{sldvc?.beatmapKey.levelId}, {sldvc?.beatmapKey.difficulty}] || Currently Saved Map: [{CurrentMap.levelId}, {CurrentMap.difficulty}]");
            //Plugin.Log.Info("TabSelectionPatch: " + TabSelectionPatch.GetIfTabIsSelected(TabName) + ", Maps equal? " + (sldvc?.beatmapKey.Equals(CurrentMap)));
            //Plugin.Log.Info("Are we on the tab? " + TabSelectionPatch.IsOnModsTab);
            if (!TabSelectionPatch.GetIfTabIsSelected(TabName) || !TabSelectionPatch.IsOnModsTab)
                return;
#if NEW_VERSION
            if (
                !forceRefresh
                && (sldvc?.beatmapKey.levelId?.Equals(CurrentMap.levelId) ?? false)
                && sldvc.beatmapKey.difficulty == CurrentMap.difficulty
            )
                return; // 1.37.0 and above
#else
            if (!forceRefresh && (sldvc?.selectedDifficultyBeatmap?.Equals(CurrentMap) ?? false))
                return; // 1.34.2 and below
#endif
            AsyncLock.Releaser? theLock = await RefreshLock.TryLockAsync();
            if (theLock is null)
                return;
            using (theLock.Value)
            {
                try
                {
                    CurrentLeaderboard = pc.CalcLeaderboard;
                    UpdateMods();
                    TargetPP = await UpdateTargetPP();
                    await UpdateTabDisplay(forceRefresh, false);
                    await UpdatePlayTable();
                }
                catch (Exception ex)
                {
                    Plugin.Log.Error("There was an issue refreshing the " + TabName + " display!");
                    Plugin.Log.Error(ex);
                }
            }
        }

        private async Task UpdatePlayTable()
        {
            if (CurrentProfile is null)
                return;
            if (IsPlayTableOpen)
                await DelayUpdatePlayTable(CurrentProfile.PlayTable).AsTask(sldvc).ConfigureAwait(false);
            else
                UpdatePlayTableOnOpen = true;
        }

        public void ClearMapTabs()
        {
            TabMapInfo["Capture"] = default;
            TabMapInfo["Relative Values"] = default;
            ClanTableTable?.ClearTable();
            RelativeTableTable?.ClearTable();
            CurrentMap = default;
        }

        public void ResetTabs()
        {
#if NEW_VERSION
            if (CurrentMap.Equals(default) && CurrentDiff.Equals(default))
                return;
#else
            if (CurrentMap is null && CurrentDiff.Equals(default))
                return;
#endif
            string[] tabNames = [.. TabMapInfo.Keys];
            foreach (string s in tabNames)
                TabMapInfo[s] = default;
            PPTableTable?.ClearTable();
            PercentTableTable?.ClearTable();
            ClanTableTable?.ClearTable();
            RelativeTableTable?.ClearTable();
            CurrentMap = default;
            CurrentDiff = default;
        }

        private void UpdateTabSliders(int amount = -1)
        {
            if (amount <= 0)
                amount = pc.SliderIncrementNum;
            HelpfulMisc.SetIncrements(amount, MinPPSlider, MaxPPSlider, CA_PPSliderSlider, ProfilePPSlider);
            HelpfulMisc.SetIncrements(amount, 1f / 100f, MinAccSlider, MaxAccSlider, CA_PercentSliderSlider);
        }

        public void Initialize()
        {
            CurrentLeaderboard = pc.CalcLeaderboard;
            ShowTrueID = pc.ShowTrueID;
            PercentSliderMin = pc.PercentSliderMin;
            PercentSliderMax = pc.PercentSliderMax;
            PPSliderMin = pc.PPSliderMin;
            PPSliderMax = pc.PPSliderMax;
            SliderIncrementNum = pc.SliderIncrementNum;

            ChangeMapListeners(true);
            InitFormatters(pc);

            TabSelectionPatch.AddToTabSelectedAction(
                TabName,
                () =>
                {
                    if (sldvc is not null && gmpc is not null)
                        Refresh();
                }
            );

            settingsHandler.PropertyChanged += (parent, args) =>
            {
                if (CurrentMap != default && args.PropertyName.Equals(nameof(SettingsHandler.Target)))
                    ClearMapTabs();
            };
        }
        #endregion
    }
}
