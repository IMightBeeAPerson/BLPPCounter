using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BeatSaberMarkupLanguage.Attributes;
using BeatSaberMarkupLanguage.Components;
using BeatSaberMarkupLanguage.Components.Settings;
using BLPPCounter.Counters;
using BLPPCounter.Helpfuls;
using BLPPCounter.Settings.Configs;
using BLPPCounter.Utils;
using BLPPCounter.Utils.API_Handlers;
using BLPPCounter.Utils.Enums;
using BLPPCounter.Utils.List_Settings;
using BLPPCounter.Utils.Misc_Classes;
using BLPPCounter.Utils.Safety;
using BLPPCounter.Utils.Serializable_Classes;
using HMUI;
using IPA.Utilities.Async;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Zenject;

namespace BLPPCounter.Settings.SettingHandlers.MenuSettingHandlers
{
    /*<checkbox-setting text='Local Replays' apply-on-change='true' value='LocalReplay' hover-hint='Check for any local replays before loading from website' active='false'/>
     <dropdown-list-setting text='Playlists' apply-on-change='true' value='ChosenPlaylist' options='PlNames' hover-hint='A playlist to load' active='false'/>
    <button text='Load Playlist' on-click='LoadPlaylist' hover-hint='Loads the selected playlist into cache to prevent lag' active='false'/>*/
    //(?<att1>\[[^"\]]+)"[^"\]]+"(?<att2>\)]).*(?<bre>[\n\r]\s*)(?<words>(?:\w+ )+)(?!;)(?<name>\w+)
    //${att1}nameof(${name})${att2}${bre}${words}${name}
    internal class SettingsHandler : SafeNotifyPropertyChanged
    {
#pragma warning disable CS0649, IDE0044
        #region Variables
        internal Action? OnTypesOfPPChanged;

        [Inject]
        private readonly PluginConfig pc = null!;

        [Inject]
        private readonly MainThreadDispatcher dispatcher = null!;

#if NEW_VERSION
        internal static readonly int MENU_HEIGHT = 70;
        internal static readonly int MENU_ANCHOR = 0;
#else
        internal static readonly int MENU_HEIGHT = 60;
        internal static readonly int MENU_ANCHOR = 5;
#endif
        #endregion
        #region Init
        public SettingsHandler()
        {
            OnTypesOfPPChanged += () =>
            {
                if (CounterList is not null)
                    CounterList.UpdateListSetting(TypesOfPP);
                else if (!TypesOfPP.Any(obj => ((string)obj).Equals(PPType)))
                    PPType = (string)TypesOfPP[0];

                if (DefaultCounterList is not null)
                    DefaultCounterList.UpdateListSetting(RelativeDefaultList);
                else if (!RelativeDefaultList.Any(obj => ((string)obj).Equals(RelativeDefault)))
                    RelativeDefault = (string)RelativeDefaultList[0];

                TheCounter.SettingChanged = true;
            };
            PropertyChanged += (obj, args) =>
            {
                switch (args.PropertyName)
                {
                    case nameof(Leaderboard):
                        OnTypesOfPPChanged?.Invoke();
                        break;
                    case nameof(CalcLeaderboard):
                        PpInfoTabHandler.Instance.ChangeTabSettings = true;
                        PpInfoTabHandler.Instance.CalcSelector.ReceiveValue();
                        PpInfoTabHandler.Instance.ResetTabs();
                        break;
                    case nameof(UseUnranked):
                    case nameof(LocalReplaysOnly):
                        TheCounter.SettingChanged = true;
                        break;
                    case nameof(DecimalPrecision):
                        string hold = "";
                        for (int i = 0; i < pc.DecimalPrecision; i++)
                            hold += "#";
                        HelpfulFormatter.NUMBER_TOSTRING_FORMAT =
                            pc.DecimalPrecision > 0
                                ? pc.FormatSettings.NumberFormat.Replace("#", "#." + hold)
                                : pc.FormatSettings.NumberFormat;
                        break;
                    case nameof(Target):
                        PpInfoTabHandler.Instance.ResetTabs();
                        break;
                    case nameof(APITimeout):
                        APIHandler.ClientTimeout = TimeSpan.FromSeconds(pc.APITimeout);
                        break;
                    case nameof(LocalReplays):
                        if (pc.LocalReplays)
                            LocalReplayHandler.LoadReplays();
                        TheCounter.SettingChanged = true;
                        break;
                }
            };
        }
#pragma warning disable IDE0051

        [UIAction("#post-parse")]
        private void PostParse()
        {
            TargetPostParse();
#if !NEW_VERSION
            LeaderboardPostParse();
#endif
        }
#pragma warning restore IDE0051
        #endregion
        #region General Settings
        [UIValue(nameof(DecimalPrecision))]
        public int DecimalPrecision
        {
            get => pc.DecimalPrecision;
            set
            {
                pc.DecimalPrecision = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(FontSize))]
        public float FontSize
        {
            get => pc.FontSize;
            set
            {
                pc.FontSize = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ShowLbl))]
        public bool ShowLbl
        {
            get => pc.ShowLbl;
            set
            {
                pc.ShowLbl = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PPFC))]
        public bool PPFC
        {
            get => pc.PPFC;
            set
            {
                pc.PPFC = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(SplitVals))]
        public bool SplitVals
        {
            get => pc.SplitPPVals;
            set
            {
                pc.SplitPPVals = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ExtraInfo))]
        public bool ExtraInfo
        {
            get => pc.ExtraInfo;
            set
            {
                pc.ExtraInfo = value;
                NotifyPropertyChanged();
            }
        }

        [UIComponent(nameof(CounterList))]
        private ListSetting? CounterList;

        [UIValue(nameof(TypesOfPP))]
        public List<object> TypesOfPP => [.. TheCounter.DisplayNames];

        [UIValue(nameof(UpdateAfterTime))]
        public bool UpdateAfterTime
        {
            get => pc.UpdateAfterTime;
            set
            {
                pc.UpdateAfterTime = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(UpdateTime))]
        public float UpdateTime
        {
            get => pc.UpdateTime;
            set
            {
                pc.UpdateTime = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(PPType))]
        public string PPType
        {
            get => pc.PPType;
            set
            {
                pc.PPType = value;
                NotifyPropertyChanged();
            }
        }

        #endregion
        #region Leaderboard Settings
        private LeaderboardSettingsHandler LeaderboardSettings => LeaderboardSettingsHandler.Instance;

        [UIObject(nameof(LeaderboardModal))]
        private GameObject LeaderboardModal = null!;

        [UIComponent(nameof(LeaderboardTable))]
        internal CustomCellListTableData LeaderboardTable = null!;

        [UIComponent(nameof(LeaderboardSelector))]
        internal ListSetting LeaderboardSelector = null!;

        [UIComponent(nameof(CalcSelector))]
        internal ListSetting CalcSelector = null!;

        [UIValue(nameof(Leaderboard))]
        private string Leaderboard
        {
            get => LeaderboardSettings.NextLeaderboardToAdd.ToString();
            set
            {
                LeaderboardSettings.NextLeaderboardToAdd = (Leaderboards)Enum.Parse(typeof(Leaderboards), value);
                NotifyPropertyChanged();
            }
        }

        internal void LeaderboardUpdate() => NotifyPropertyChanged();

        [UIValue(nameof(LeaderboardList))]
        private List<object> LeaderboardList => LeaderboardSettings.LeaderboardList;

        [UIValue(nameof(LeaderboardOptions))]
        private List<object> LeaderboardOptions => LeaderboardSettings.LeaderboardOptions;

        [UIAction(nameof(AddLeaderboard))]
        private void AddLeaderboard() => LeaderboardSettings.AddCell();

        [UIValue(nameof(CalcLeaderboard))]
        private string CalcLeaderboard
        {
            get => pc.CalcLeaderboard.ToString();
            set
            {
                pc.CalcLeaderboard = (Leaderboards)Enum.Parse(typeof(Leaderboards), value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(CalcLeaderboards))]
        private List<object> CalcLeaderboards => [.. LeaderboardSettings.UsableLeaderboards.Select(a => a.ToString())];

        [UIValue(nameof(UseUnranked))]
        public bool UseUnranked
        {
            get => pc.UseUnranked;
            set
            {
                pc.UseUnranked = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(LeaderInLabel))]
        public bool LeaderInLabel
        {
            get => pc.LeaderInLabel;
            set
            {
                pc.LeaderInLabel = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(HuntLoads))]
        public bool HuntLoads
        {
            get => pc.HuntLoads;
            set
            {
                pc.HuntLoads = value;
                NotifyPropertyChanged();
            }
        }

#if !NEW_VERSION
        private void LeaderboardPostParse()
        {
            IEnumerator WaitThenUpdate()
            {
                yield return new WaitForEndOfFrame();
                (LeaderboardModal.transform as RectTransform).sizeDelta = new Vector2(100, 80);
            }
            dispatcher.EnqueueRoutine(WaitThenUpdate());
        }
#endif
        #endregion
        #region Misc Settings
        [UIAction(nameof(ClearCache))]
        public void ClearCache()
        {
            ClanCounter.ClearCache();
            TheCounter.ClearCounter();
        }

        [UIValue(nameof(MaxNameLength))]
        public int MaxNameLength
        {
            get => pc.MaxNameLength;
            set
            {
                pc.MaxNameLength = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(APITimeout))]
        public int APITimeout
        {
            get => pc.APITimeout;
            set
            {
                pc.APITimeout = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(UseGrad))]
        public bool UseGrad
        {
            get => pc.UseGrad;
            set
            {
                pc.UseGrad = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradMin))]
        private Color ColorGradMin
        {
            get => HelpfulMisc.ConvertColor(pc.ColorGradMin);
            set
            {
                pc.ColorGradMin = HelpfulMisc.ConvertColor(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradMax))]
        private Color ColorGradMax
        {
            get => HelpfulMisc.ConvertColor(pc.ColorGradMax);
            set
            {
                pc.ColorGradMax = HelpfulMisc.ConvertColor(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradZero))]
        private Color ColorGradZero
        {
            get => HelpfulMisc.ConvertColor(pc.ColorGradZero);
            set
            {
                pc.ColorGradZero = HelpfulMisc.ConvertColor(value);
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradMinDark))]
        private float ColorGradMinDark
        {
            get => pc.ColorGradMinDark;
            set
            {
                pc.ColorGradMinDark = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradBlending))]
        private bool ColorGradBlending
        {
            get => pc.ColorGradBlending;
            set
            {
                pc.ColorGradBlending = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(BlendMiddleColor))]
        private bool BlendMiddleColor
        {
            get => pc.BlendMiddleColor;
            set
            {
                pc.BlendMiddleColor = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradFlipPercent))]
        private float ColorGradFlipPercent
        {
            get => pc.ColorGradFlipPercent;
            set
            {
                pc.ColorGradFlipPercent = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ColorGradMaxDiff))]
        private int ColorGradMaxDiff
        {
            get => pc.ColorGradMaxDiff;
            set
            {
                pc.ColorGradMaxDiff = value;
                NotifyPropertyChanged();
            }
        }
        #endregion
        #region Clan Counter Settings
        [UIValue(nameof(ShowClanMessage))]
        public bool ShowClanMessage
        {
            get => pc.ShowClanMessage;
            set
            {
                pc.ShowClanMessage = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(MapCache))]
        public int MapCache
        {
            get => pc.MapCache;
            set
            {
                pc.MapCache = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ClanPercentCeil))]
        public float ClanPercentCeil
        {
            get => pc.ClanPercentCeil;
            set
            {
                pc.ClanPercentCeil = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(CeilEnabled))]
        public bool CeilEnabled
        {
            get => pc.CeilEnabled;
            set
            {
                pc.CeilEnabled = value;
                NotifyPropertyChanged();
            }
        }
        #endregion
        #region Relative Counter Settings
        [UIValue(nameof(UseReplay))]
        public bool UseReplay
        {
            get => pc.UseReplay;
            set
            {
                pc.UseReplay = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ReplayMods))]
        public bool ReplayMods
        {
            get => pc.ReplayMods;
            set
            {
                pc.ReplayMods = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(DynamicAcc))]
        public bool DynamicAcc
        {
            get => pc.DynamicAcc;
            set
            {
                pc.DynamicAcc = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ShowRank))]
        public bool ShowRank
        {
            get => pc.ShowRank;
            set
            {
                pc.ShowRank = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(LocalReplays))]
        public bool LocalReplays
        {
            get => pc.LocalReplays;
            set
            {
                pc.LocalReplays = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(LocalReplaysOnly))]
        public bool LocalReplaysOnly
        {
            get => pc.LocalReplaysOnly;
            set
            {
                pc.LocalReplaysOnly = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(RelativeDefault))]
        public string RelativeDefault
        {
            get
            {
                if (RelativeDefaultList.Count == 0)
                    pc.RelativeDefault = Targeter.NO_TARGET;
                else if (!RelativeDefaultList.Contains(pc.RelativeDefault))
                    pc.RelativeDefault = (string)RelativeDefaultList[0];
                return pc.RelativeDefault;
            }
            set
            {
                pc.RelativeDefault = value;
                NotifyPropertyChanged();
            }
        }

        [UIComponent(nameof(DefaultCounterList))]
        private ListSetting? DefaultCounterList;

        [UIValue(nameof(RelativeDefaultList))]
        public List<object> RelativeDefaultList =>
            [
                .. TypesOfPP
                    .Where(a => a is string b && !RelativeCounter.DisplayName.Equals(b))
                    .Prepend(Targeter.NO_TARGET),
            ];
        #endregion
        #region Rank Counter Settings
        [UIValue(nameof(MinRank))]
        public int MinRank
        {
            get => pc.MinRank;
            set
            {
                pc.MinRank = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(MaxRank))]
        public int MaxRank
        {
            get => pc.MaxRank;
            set
            {
                pc.MaxRank = value;
                NotifyPropertyChanged();
            }
        }
        #endregion
        #region Target Settings
        [UIValue(nameof(TargeterStartupWarnings))]
        public bool TargeterStartupWarnings
        {
            get => pc.TargeterStartupWarnings;
            set
            {
                pc.TargeterStartupWarnings = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(UseSteamFriends))]
        public bool UseSteamFriends
        {
            get => pc.UseSteamFriends;
            set
            {
                pc.UseSteamFriends = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ShowEnemy))]
        public bool ShowEnemy
        {
            get => pc.ShowEnemy;
            set
            {
                pc.ShowEnemy = value;
                NotifyPropertyChanged();
            }
        }

        [UIComponent(nameof(CustomTargetText))]
        private TextMeshProUGUI CustomTargetText = null!;

        [UIComponent(nameof(CustomTargetInput))]
        private StringSetting CustomTargetInput = null!;

        [UIComponent(nameof(CustomRankText))]
        private TextMeshProUGUI CustomRankText = null!;

        [UIComponent(nameof(CustomRankInput))]
        private StringSetting CustomRankInput = null!;

        [UIComponent(nameof(ClanTargetList))]
        private CustomCellListTableData ClanTargetList = null!;

        [UIComponent(nameof(FollowerTargetList))]
        private CustomCellListTableData FollowerTargetList = null!;

        [UIComponent(nameof(CustomTargetList))]
        private CustomCellListTableData CustomTargetList = null!;

        [UIComponent(nameof(DisplayList))]
        private CustomCellListTableData DisplayList = null!;

        [UIComponent(nameof(ReloadCustomRanksButton))]
        private Button ReloadCustomRanksButton = null!;

        [UIComponent(nameof(ReloadFollowersButton))]
        private Button ReloadFollowersButton = null!;

        [UIComponent(nameof(DeleteTarget))]
        private Button DeleteTarget = null!;

#if !NEW_VERSION
        [UIObject(nameof(TargetModal))]
        private GameObject TargetModal = null!;
#endif
        private AsyncLock CustomInputLock = new();

        [UIValue(nameof(CustomTargetName))]
        public string CustomTargetName
        {
            get => "";
            set
            {
                NotifyPropertyChanged();
                UnityMainThreadTaskScheduler.Factory.StartNew(async () =>
                {
                    AsyncLock.Releaser? theLock = await CustomInputLock.TryLockAsync().ConfigureAwait(false);
                    if (theLock is null)
                        return;
                    using (theLock.Value)
                    {
                        CustomTargetText.SetText("<color=\"yellow\">Loading...</color>");
                        try
                        {
                            CustomTarget converted = await CustomTarget.ConvertToId(value);
                            if (Targeter.UsedIDs.Contains(converted.ID))
                            {
                                if (AutoSelectAddedTarget)
                                {
                                    SelectedTarget = IdToTarget[converted.ID];
                                    UpdateSelectedTarget();
                                    CustomTargetText.SetText("<color=#FFA500>Set as target, ID is in use.</color>");
                                    CustomTargetInput.Text = "";
                                    return;
                                }
                                throw new ArgumentException("this ID is already in use.");
                            }
                            pc.CustomTargets.AddSorted(converted);
                            Targeter.AddTarget(converted);
                            TargetInfo? ti =
                                GetTargetInfo((converted.ID.ToString(), converted.Rank))
                                ?? throw new NullReferenceException("TargetInfo was null.");
                            IdToTarget.Add(converted.ID, ti);
                            if (AutoSelectAddedTarget)
                            {
                                SelectedTarget = ti;
                                UpdateSelectedTarget();
                            }
                            CustomTargetText.SetText(
                                "<color=\"green\">Success"
                                    + (AutoSelectAddedTarget ? ", player set as target." : "!")
                                    + "</color>"
                            );
                            CustomTargetInput.Text = "";

                            dispatcher.EnqueueAction(UpdateTargetLists);
                        }
                        catch (Exception e)
                        {
                            Plugin.Log.Warn(e.Message);
                            CustomTargetText.SetText($"<color=\"red\">Failure, {e.Message}</color>");
                        }
                    }
                });
            }
        }

        [UIValue(nameof(CustomRank))]
        public string CustomRank
        {
            get => "";
            set
            {
                NotifyPropertyChanged();
                UnityMainThreadTaskScheduler.Factory.StartNew(async () =>
                {
                    AsyncLock.Releaser? theLock = await CustomInputLock.TryLockAsync().ConfigureAwait(false);
                    if (theLock is null)
                        return;
                    using (theLock.Value)
                    {
                        CustomRankText.SetText("<color=\"yellow\">Loading...</color>");
                        try
                        {
                            CustomTarget converted = await CustomTarget.ConvertFromRank(value);
                            if (Targeter.UsedIDs.Contains(converted.ID))
                            {
                                if (AutoSelectAddedTarget)
                                {
                                    SelectedTarget = IdToTarget[converted.ID];
                                    UpdateSelectedTarget();
                                    CustomRankText.SetText("<color=#FFA500>Set as target, ID is in use.</color>");
                                    CustomRankInput.Text = "";
                                }
                                else
                                    throw new ArgumentException("this ID is already in use.");
                                return;
                            }

                            pc.CustomTargets.AddSorted(converted);

                            Targeter.AddTarget(converted);
                            TargetInfo? ti =
                                GetTargetInfo((converted.ID.ToString(), converted.Rank))
                                ?? throw new NullReferenceException("TargetInfo was null.");

                            IdToTarget.Add(converted.ID, ti);
                            if (AutoSelectAddedTarget)
                            {
                                SelectedTarget = ti;
                                UpdateSelectedTarget();
                            }

                            CustomRankText.SetText(
                                "<color=\"green\">Success"
                                    + (AutoSelectAddedTarget ? ", player set as target." : "!")
                                    + "</color>"
                            );
                            CustomRankInput.Text = "";

                            dispatcher.EnqueueAction(UpdateTargetLists);
                        }
                        catch (Exception e)
                        {
                            Plugin.Log.Warn(e.Message);
                            Plugin.Log.Debug(e);
                            CustomRankText.SetText($"<color=\"red\">Failure, {e.Message}</color>");
                        }
                    }
                });
            }
        }

        [UIValue(nameof(UseSSRank))]
        private bool UseSSRank
        {
            get => pc.UseSSRank;
            set
            {
                pc.UseSSRank = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(Target))]
        public string Target
        {
            get => pc.Target;
            set
            {
                pc.Target = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(AutoSelectAddedTarget))]
        public bool AutoSelectAddedTarget
        {
            get => pc.AutoSelectAddedTarget;
            set
            {
                pc.AutoSelectAddedTarget = value;
                NotifyPropertyChanged();
            }
        }

        [UIValue(nameof(ClanTargetInfos))]
        private List<object> ClanTargetInfos => GetTargetList(Targeter.ClanTargets);

        [UIValue(nameof(FollowerTargetInfos))]
        private List<object> FollowerTargetInfos => GetTargetList(Targeter.FollowerTargets);

        [UIValue(nameof(CustomTargetInfos))]
        private List<object> CustomTargetInfos => GetTargetList(Targeter.CustomTargets);

        [UIValue(nameof(SelectedTargetInfo))]
        private List<object> SelectedTargetInfo => SelectedTarget is null ? [] : [SelectedTarget];
        private object? SelectedTarget = null;
        private SelectableCell LastCellSelected = null!;
        private bool TargetMenuIsOpen = false;
        private readonly Dictionary<long, TargetInfo> IdToTarget = [];

        [UIAction(nameof(ResetTarget))]
        private void ResetTarget()
        {
            Target = Targeter.NO_TARGET;
            pc.TargetID = -1;
            SelectedTarget = null;
            UpdateSelectedTarget();
        }

        [UIAction(nameof(ReloadCustomRanks))]
        private void ReloadCustomRanks()
        {
            ReloadCustomRanksButton.interactable = false;
            Task.Run(() =>
            {
                Targeter.ReloadCustomPlayers();
                ReloadCustomRanksButton.interactable = true;
            });
        }

        [UIAction(nameof(ReloadFollowers))]
        private void ReloadFollowers()
        {
            ReloadFollowersButton.interactable = false;
            Task.Run(() =>
            {
                Targeter.ReloadFollowers();
                ReloadFollowersButton.interactable = true;
            });
        }

        [UIAction(nameof(RemoveTarget))]
        private void RemoveTarget()
        {
            if (pc.Target.Equals(Targeter.NO_TARGET))
                return;
            if (!Targeter.DeleteTarget(pc.TargetID.ToString()))
                return;
            SelectedTarget = null;
            UpdateSelectedTarget();
            if (TargetMenuIsOpen)
            {
#if NEW_VERSION
                CustomTargetList.Data = CustomTargetInfos;
                CustomTargetList.TableView.ReloadData();
#else
                CustomTargetList.data = CustomTargetInfos;
                CustomTargetList.tableView.ReloadData();
#endif
            }
        }
#pragma warning disable IDE0051
        [UIAction("#ShowTargetMenu")]
        private void ShowTargetMenu()
        {
            IEnumerator WaitThenUpdate()
            {
                yield return new WaitForEndOfFrame();
                UpdateTargetLists();
            }
            dispatcher.EnqueueRoutine(WaitThenUpdate());
            TargetMenuIsOpen = true;
        }

        [UIAction("#HideTargetMenu")]
        private void HideTargetMenu()
        {
            TargetMenuIsOpen = false;
        }
#pragma warning restore IDE0051
        public void UpdateTargetLists()
        {
            if (!TargetMenuIsOpen)
                return;
#if NEW_VERSION
            ClanTargetList.Data = ClanTargetInfos;
            FollowerTargetList.Data = FollowerTargetInfos;
            CustomTargetList.Data = CustomTargetInfos;
            DisplayList.Data = SelectedTargetInfo;

            ClanTargetList.TableView.ReloadData();
            FollowerTargetList.TableView.ReloadData();
            CustomTargetList.TableView.ReloadData();
            DisplayList.TableView.ReloadData();
#else
            ClanTargetList.data = ClanTargetInfos;
            FollowerTargetList.data = FollowerTargetInfos;
            CustomTargetList.data = CustomTargetInfos;
            DisplayList.data = SelectedTargetInfo;

            ClanTargetList.tableView.ReloadData();
            FollowerTargetList.tableView.ReloadData();
            CustomTargetList.tableView.ReloadData();
            DisplayList.tableView.ReloadData();
#endif
        }

        private void UpdateSelectedTarget()
        {
            if (SelectedTarget is TargetInfo ti && ti is not null)
            {
                ti.SetAsTarget();
                DeleteTarget.interactable = Targeter.CustomTargets.Any(token => token.ID.Equals(ti.RealID));
            }
            else
            {
                Target = Targeter.NO_TARGET;
                pc.TargetID = -1;
                DeleteTarget.interactable = false;
            }
            if (!TargetMenuIsOpen)
                return;
#if NEW_VERSION
            DisplayList.Data = SelectedTargetInfo;
            DisplayList.TableView.ReloadData();
#else
            DisplayList.data = SelectedTargetInfo;
            DisplayList.tableView.ReloadData();
#endif
        }

        private void UpdateSelectedTarget(SelectableCell setCell)
        {
            LastCellSelected?.SetSelected(false, SelectableCell.TransitionType.Instant, null, false);
            LastCellSelected = setCell;
            UpdateSelectedTarget();
        }

        private List<object> GetTargetList(IEnumerable<(string ID, int Rank)> ids)
        {
            if (ids is null)
                return [];
            List<object> outp = new(ids.Count());
            foreach ((string? id, int rank) in ids)
            {
                if (!Targeter.IDtoNames.TryGetValue(id, out string name))
                {
                    Plugin.Log.Warn($"ID \"{id}\" not found to have a display name.");
                    continue;
                }
                outp.Add(new TargetInfo(name, id, (Leaderboards.Beatleader, rank)));
            }
            return outp;
        }

        private TargetInfo? GetTargetInfo((string ID, int Rank) id)
        {
            if (!Targeter.IDtoNames.TryGetValue(id.ID, out string name))
            {
                Plugin.Log.Warn($"ID \"{id}\" not found to have a display name.");
                return null;
            }
            return new TargetInfo(name, id.ID, (Leaderboards.Beatleader, id.Rank));
        }

        private void TargetPostParse()
        {
#if NEW_VERSION
            ClanTargetList.TableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = ClanTargetInfos[index];
                UpdateSelectedTarget(view.GetCellAtIndex(index));
            };
            FollowerTargetList.TableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = FollowerTargetInfos[index];
                UpdateSelectedTarget(view.GetCellAtIndex(index));
            };
            CustomTargetList.TableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = CustomTargetInfos[index];
                UpdateSelectedTarget(view.GetCellAtIndex(index));
            };
#else
            IEnumerator WaitThenUpdate()
            {
                yield return new WaitForEndOfFrame();
                (TargetModal.transform as RectTransform).sizeDelta = new Vector2(200, 80);
            }
            dispatcher.EnqueueRoutine(WaitThenUpdate());
            ClanTargetList.tableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = ClanTargetInfos[index];
                UpdateSelectedTarget(ClanTargetList.CellForIdx(view, index));
            };
            FollowerTargetList.tableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = FollowerTargetInfos[index];
                UpdateSelectedTarget(FollowerTargetList.CellForIdx(view, index));
            };
            CustomTargetList.tableView.didSelectCellWithIdxEvent += (view, index) =>
            {
                SelectedTarget = CustomTargetInfos[index];
                UpdateSelectedTarget(CustomTargetList.CellForIdx(view, index));
            };
#endif
        }

        internal void SetSelectedTargetRelation()
        {
            //This will be slow, but it only runs once so who cares.
            foreach (object cell in CustomTargetInfos.Union(FollowerTargetInfos).Union(ClanTargetInfos))
                if (cell is TargetInfo ti && long.TryParse(ti.RealID, out long ID))
                    IdToTarget.Add(ID, ti);
            if (pc.TargetID > -1)
            {
                SelectedTarget = IdToTarget[pc.TargetID];
                if (TargetMenuIsOpen)
                    UpdateSelectedTarget();
            }
            int count = 0;
            while (DeleteTarget is null && count++ < 20)
                Thread.Sleep(50);
            if (DeleteTarget is null)
                Plugin.Log.Warn("DeleteTarget button not initialized.");
            else
                DeleteTarget.interactable = Targeter.CustomTargets.Any(token =>
                    token.ID.Equals(pc.TargetID.ToString())
                );
        }
        #endregion
    }
}
